package com.mat3files

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Свой «чип» вместо стандартного: выбранный — полностью скруглённая «таблетка»,
 * невыбранный — скруглённый прямоугольник без рамки. При выборе форма плавно «перетекает».
 * Имя и параметры совпадают с material3.FilterChip, поэтому подменяет его во всём приложении.
 */
@Composable
fun FilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val corner by animateDpAsState(
        if (selected) 30.dp else 16.dp,
        spring(dampingRatio = 0.6f, stiffness = 450f), label = "chipCorner",
    )
    val bg by animateColorAsState(if (selected) cs.primaryContainer else cs.surfaceContainerHighest, label = "chipBg")
    val fg by animateColorAsState(if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant, label = "chipFg")
    Row(
        modifier
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(corner))
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        CompositionLocalProvider(LocalContentColor provides fg) {
            leadingIcon?.invoke()
            ProvideTextStyle(TextStyle(fontWeight = FontWeight.Bold, fontSize = 14.sp)) { label() }
            trailingIcon?.invoke()
        }
    }
}

/** Цветной «блок» с иконкой: используется в окнах и списках, чтобы интерфейс не был блёклым. */
@Composable
fun IconBlob(icon: ImageVector, container: Color, content: Color, size: Dp = 44.dp, corner: Dp = 16.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(corner)).background(container),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = content, modifier = Modifier.size(size * 0.52f)) }
}

/** Палитра для цветных блоков: берём из динамической темы. */
@Composable
fun blobColors(index: Int): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (index % 4) {
        0 -> cs.primaryContainer to cs.onPrimaryContainer
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        2 -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.primary to cs.onPrimary
    }
}

// ───────────────────────── Диалоги ─────────────────────────

/**
 * Стильное окно: крупное скругление, цветной значок, жирный заголовок, кнопки-«таблетки».
 * [actions] — свои кнопки; если не заданы, строятся из confirmText / dismissText.
 */
@Composable
fun StyledDialog(
    title: String,
    onDismiss: () -> Unit,
    icon: ImageVector? = null,
    danger: Boolean = false,
    confirmText: String? = null,
    onConfirm: () -> Unit = {},
    confirmEnabled: Boolean = true,
    dismissText: String? = stringResource(R.string.cancel),
    actions: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val appear by animateFloatAsState(
        if (shown) 1f else 0f,
        spring(dampingRatio = 0.75f, stiffness = 500f), label = "dialogAppear",
    )
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(36.dp),
            color = cs.surfaceContainerHigh,
            modifier = Modifier
                .padding(horizontal = 20.dp)
                .widthIn(max = 440.dp)
                .fillMaxWidth()
                .graphicsLayer {
                    val s = 0.9f + 0.1f * appear
                    scaleX = s
                    scaleY = s
                    alpha = appear.coerceIn(0f, 1f)
                },
        ) {
            Column(Modifier.padding(24.dp)) {
                if (icon != null) {
                    IconBlob(
                        icon,
                        if (danger) cs.errorContainer else cs.primaryContainer,
                        if (danger) cs.onErrorContainer else cs.onPrimaryContainer,
                        size = 56.dp,
                        corner = 20.dp,
                    )
                    Spacer(Modifier.height(16.dp))
                }
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                content()
                Spacer(Modifier.height(22.dp))
                if (actions != null) {
                    actions()
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
                        if (dismissText != null) {
                            FilledTonalButton(onClick = onDismiss) { Text(dismissText, fontWeight = FontWeight.SemiBold) }
                        }
                        if (confirmText != null) {
                            Button(
                                onClick = onConfirm,
                                enabled = confirmEnabled,
                                colors = if (danger) {
                                    ButtonDefaults.buttonColors(containerColor = cs.error, contentColor = cs.onError)
                                } else {
                                    ButtonDefaults.buttonColors()
                                },
                            ) { Text(confirmText, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }
            }
        }
    }
}

/** Кнопка на всю ширину для окон с несколькими вариантами. */
@Composable
fun WideButton(text: String, onClick: () -> Unit, danger: Boolean = false, tonal: Boolean = false, enabled: Boolean = true) {
    val cs = MaterialTheme.colorScheme
    val mod = Modifier.fillMaxWidth().height(48.dp)
    when {
        danger -> FilledTonalButton(
            onClick = onClick, modifier = mod, enabled = enabled,
            colors = ButtonDefaults.filledTonalButtonColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
        ) { Text(text, fontWeight = FontWeight.SemiBold) }
        tonal -> FilledTonalButton(onClick = onClick, modifier = mod, enabled = enabled) { Text(text, fontWeight = FontWeight.SemiBold) }
        else -> Button(onClick = onClick, modifier = mod, enabled = enabled) { Text(text, fontWeight = FontWeight.SemiBold) }
    }
}

/** Поле ввода в окнах: заливка вместо рамки, крупное скругление. */
@Composable
fun DialogField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    suffix: String? = null,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        suffix = if (suffix != null) ({ Text(suffix) }) else null,
        singleLine = true,
        shape = RoundedCornerShape(22.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = cs.surfaceContainerHighest,
            unfocusedContainerColor = cs.surfaceContainerHighest,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
        ),
        modifier = modifier.fillMaxWidth(),
    )
}

// ───────────────────────── Уведомления ─────────────────────────

/** Уведомление-«таблетка» с цветным значком вместо серой плашки. */
@Composable
fun StyledSnackbarHost(state: SnackbarHostState, errors: Set<String>, modifier: Modifier = Modifier) {
    SnackbarHost(state, modifier) { data ->
        val message = data.visuals.message
        val isError = message in errors
        val cs = MaterialTheme.colorScheme
        Row(
            Modifier
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .shadow(8.dp, RoundedCornerShape(30.dp))
                .clip(RoundedCornerShape(30.dp))
                .background(if (isError) cs.errorContainer else cs.primaryContainer)
                .padding(start = 8.dp, end = 22.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(if (isError) cs.error else cs.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (isError) Icons.Rounded.Warning else Icons.Rounded.Check,
                    null,
                    tint = if (isError) cs.onError else cs.onPrimary,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(Modifier.size(12.dp))
            Text(
                message,
                color = if (isError) cs.onErrorContainer else cs.onPrimaryContainer,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}
