package com.mat3files

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/** Все настройки внешнего вида в одном месте. */
data class ThemeSettings(
    val mode: Int = 0,
    val amoled: Boolean = false,
    val source: Int = 0,
    val preset: Int = 0,
    val customHue: Float = 265f,
    val customSat: Float = 1f,
)

/** Готовые акценты: оттенок (null — классический фиолетовый M3). */
private val Hues = listOf(null, 215f, 150f, 340f, 28f, 180f, 55f)

val ThemeSwatches: List<Color> = Hues.map { h ->
    if (h == null) Color(0xFF6750A4) else Color.hsl(h, 0.55f, 0.45f)
}

private val LightBaseline = lightColorScheme(
    primary = Color(0xFF6750A4), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFEADDFF), onPrimaryContainer = Color(0xFF21005D),
    secondary = Color(0xFF625B71), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE8DEF8), onSecondaryContainer = Color(0xFF1D192B),
    tertiary = Color(0xFF7D5260), onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFFEF7FF), onBackground = Color(0xFF1D1B20),
    surface = Color(0xFFFEF7FF), onSurface = Color(0xFF1D1B20),
    surfaceVariant = Color(0xFFE7E0EC), onSurfaceVariant = Color(0xFF49454F),
    surfaceContainerLow = Color(0xFFF7F2FA), surfaceContainer = Color(0xFFF3EDF7),
    surfaceContainerHigh = Color(0xFFECE6F0), surfaceContainerHighest = Color(0xFFE6E0E9),
    outline = Color(0xFF79747E),
)

private val DarkBaseline = darkColorScheme(
    primary = Color(0xFFD0BCFF), onPrimary = Color(0xFF381E72),
    primaryContainer = Color(0xFF4F378B), onPrimaryContainer = Color(0xFFEADDFF),
    secondary = Color(0xFFCCC2DC), onSecondary = Color(0xFF332D41),
    secondaryContainer = Color(0xFF4A4458), onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = Color(0xFFEFB8C8), onTertiary = Color(0xFF492532),
    background = Color(0xFF141218), onBackground = Color(0xFFE6E0E9),
    surface = Color(0xFF141218), onSurface = Color(0xFFE6E0E9),
    surfaceVariant = Color(0xFF49454F), onSurfaceVariant = Color(0xFFCAC4D0),
    surfaceContainerLow = Color(0xFF1D1B20), surfaceContainer = Color(0xFF211F26),
    surfaceContainerHigh = Color(0xFF2B2930), surfaceContainerHighest = Color(0xFF36343B),
    outline = Color(0xFF938F99),
)

private fun c(hue: Float, s: Float, l: Float) = Color.hsl(((hue % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), l)

/** Палитра из оттенка и «насыщенности» (приближение тональных палитр Material 3). */
fun hueScheme(h: Float, dark: Boolean, sat: Float = 1f): ColorScheme =
    if (dark) darkColorScheme(
        primary = c(h, .80f * sat, .80f), onPrimary = c(h, .60f * sat, .18f),
        primaryContainer = c(h, .40f * sat, .30f), onPrimaryContainer = c(h, .90f * sat, .90f),
        secondary = c(h, .30f * sat, .78f), onSecondary = c(h, .25f * sat, .18f),
        secondaryContainer = c(h, .22f * sat, .27f), onSecondaryContainer = c(h, .45f * sat, .90f),
        tertiary = c(h + 60f, .50f * sat, .78f), onTertiary = c(h + 60f, .40f * sat, .18f),
        background = c(h, .12f * sat, .09f), onBackground = c(h, .10f * sat, .90f),
        surface = c(h, .12f * sat, .09f), onSurface = c(h, .10f * sat, .90f),
        surfaceVariant = c(h, .10f * sat, .26f), onSurfaceVariant = c(h, .12f * sat, .78f),
        surfaceContainerLow = c(h, .12f * sat, .11f), surfaceContainer = c(h, .12f * sat, .13f),
        surfaceContainerHigh = c(h, .11f * sat, .17f), surfaceContainerHighest = c(h, .10f * sat, .21f),
        outline = c(h, .08f * sat, .60f),
    ) else lightColorScheme(
        primary = c(h, .45f * sat, .40f), onPrimary = Color.White,
        primaryContainer = c(h, .90f * sat, .90f), onPrimaryContainer = c(h, .80f * sat, .14f),
        secondary = c(h, .20f * sat, .40f), onSecondary = Color.White,
        secondaryContainer = c(h, .40f * sat, .89f), onSecondaryContainer = c(h, .30f * sat, .14f),
        tertiary = c(h + 60f, .35f * sat, .40f), onTertiary = Color.White,
        background = c(h, .40f * sat, .98f), onBackground = c(h, .10f * sat, .11f),
        surface = c(h, .40f * sat, .98f), onSurface = c(h, .10f * sat, .11f),
        surfaceVariant = c(h, .25f * sat, .90f), onSurfaceVariant = c(h, .12f * sat, .30f),
        surfaceContainerLow = c(h, .35f * sat, .96f), surfaceContainer = c(h, .30f * sat, .94f),
        surfaceContainerHigh = c(h, .25f * sat, .92f), surfaceContainerHighest = c(h, .20f * sat, .90f),
        outline = c(h, .06f * sat, .46f),
    )

@Composable
fun Mat3FilesTheme(settings: ThemeSettings = ThemeSettings(), content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = when (settings.mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    var scheme = when {
        settings.source == 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        settings.source == 2 -> hueScheme(settings.customHue, dark, settings.customSat)
        else -> {
            val hue = Hues.getOrNull(settings.preset)
            when {
                hue != null -> hueScheme(hue, dark)
                dark -> DarkBaseline
                else -> LightBaseline
            }
        }
    }
    if (dark && settings.amoled) {
        scheme = scheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainerLow = Color(0xFF080808),
            surfaceContainer = Color(0xFF0E0E0E),
            surfaceContainerHigh = Color(0xFF161616),
            surfaceContainerHighest = Color(0xFF1F1F1F),
        )
    }
    // значки в строке состояния должны читаться и при принудительной светлой/тёмной теме
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
