package com.mat3files

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File

// ───────────────────────── Корзина ─────────────────────────

@Composable
fun TrashScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val entries = vm.trash.entries
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = stringResource(R.string.trash_title),
            subtitle = stringResource(R.string.trash_subtitle),
            onBack = vm::back,
        ) {
            TextButton(onClick = { vm.dialog = DialogState.EmptyTrash }, enabled = entries.isNotEmpty()) {
                Text(stringResource(R.string.trash_empty_action))
            }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.trash_empty), color = cs.onSurfaceVariant)
            }
            return
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
            items(entries, key = { it.id }) { e ->
                val kind = kindOf(e.name, e.isDir)
                val (bg, fg) = kindColors(kind)
                Row(
                    Modifier
                        .animateItem()
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(bg),
                        contentAlignment = Alignment.Center,
                    ) { Icon(kindIcon(kind), null, tint = fg) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text(
                            File(e.original).parent.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            formatSize(e.size) + " · " + formatDate(e.time),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { vm.restoreFromTrash(e.id) }) {
                        Icon(Icons.Rounded.Restore, stringResource(R.string.trash_restore), tint = cs.primary)
                    }
                    IconButton(onClick = { vm.deleteForever(e.id) }) {
                        Icon(Icons.Rounded.DeleteForever, stringResource(R.string.trash_delete_forever), tint = cs.error)
                    }
                }
            }
        }
    }
}

// ───────────────────────── Анализ памяти ─────────────────────────

@Composable
fun AnalyzeScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val root = vm.roots.firstOrNull()?.path
    // размеры всех папок верхнего уровня считаем параллельно
    val data by produceState<List<Pair<File, Long>>?>(null, root) {
        value = if (root == null) emptyList() else withContext(Dispatchers.IO) {
            val kids = File(root).listFiles().orEmpty().filter { !it.name.startsWith(".") }
            coroutineScope { kids.map { k -> async { k to FileOps.totalSize(k) } }.awaitAll() }
                .sortedByDescending { it.second }
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = stringResource(R.string.analyze_title),
            subtitle = stringResource(R.string.analyze_subtitle),
            onBack = vm::back,
        )
        val list = data
        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return
        }
        val max = (list.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
            items(list, key = { it.first.path }) { (file, size) ->
                val fraction by animateFloatAsState(size.toFloat() / max, tween(700), label = "bar")
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(cs.surfaceContainerHigh)
                        .pressable({
                            if (file.isDirectory) vm.push(Screen.Folder(file.absolutePath))
                        })
                        .padding(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(file.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(formatSize(size), color = cs.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(cs.surfaceContainerHighest)) {
                        Box(Modifier.fillMaxWidth(fraction.coerceIn(0.01f, 1f)).height(10.dp).clip(RoundedCornerShape(5.dp)).background(cs.primary))
                    }
                }
            }
        }
    }
}
