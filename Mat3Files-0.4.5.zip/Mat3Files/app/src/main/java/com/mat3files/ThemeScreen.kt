package com.mat3files

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.remember
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun ThemeScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val t = vm.theme
    val canDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    // состояние Shizuku/root обновляется, пока экран открыт
    LaunchedEffect(Unit) {
        while (true) {
            Shell.refresh()
            delay(1000)
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.theme_title), null, vm::back)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // ── режим ──
            SettingCard(R.string.theme_mode) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.mode_system, R.string.mode_light, R.string.mode_dark).forEachIndexed { i, res ->
                        FilterChip(selected = t.mode == i, onClick = { vm.setThemeMode(i) }, label = { Text(stringResource(res)) })
                    }
                }
                SwitchRow(R.string.amoled, t.amoled, vm::setAmoled)
            }

            // ── цвета ──
            SettingCard(R.string.color_title) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = t.source == 0 && canDynamic,
                        enabled = canDynamic,
                        onClick = { vm.setColorSource(0) },
                        label = { Text(stringResource(R.string.source_system)) },
                    )
                    FilterChip(
                        selected = t.source == 1 || (t.source == 0 && !canDynamic),
                        onClick = { vm.setColorSource(1) },
                        label = { Text(stringResource(R.string.source_presets)) },
                    )
                    FilterChip(
                        selected = t.source == 2,
                        onClick = { vm.setColorSource(2) },
                        label = { Text(stringResource(R.string.source_custom)) },
                    )
                }
                if (t.source == 1 || (t.source == 0 && !canDynamic)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ThemeSwatches.forEachIndexed { i, color ->
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .then(if (i == t.preset) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                                    .clickable { vm.setPreset(i) },
                                contentAlignment = Alignment.Center,
                            ) { if (i == t.preset) Icon(Icons.Rounded.Check, null, tint = Color.White) }
                        }
                    }
                }
                if (t.source == 2) {
                    Text(stringResource(R.string.custom_hue), style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = t.customHue,
                        onValueChange = { vm.setCustomColor(it, t.customSat) },
                        valueRange = 0f..360f,
                    )
                    Text(stringResource(R.string.custom_sat), style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = t.customSat,
                        onValueChange = { vm.setCustomColor(t.customHue, it) },
                        valueRange = 0.3f..1f,
                    )
                }
                // живой предпросмотр палитры
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(cs.primary, cs.primaryContainer, cs.secondaryContainer, cs.tertiaryContainer).forEach { c ->
                        Box(Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(12.dp)).background(c))
                    }
                }
            }

            // ── список ──
            SettingCard(R.string.density_title) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.density_compact, R.string.density_normal, R.string.density_spacious).forEachIndexed { i, res ->
                        FilterChip(selected = vm.density == i, onClick = { vm.changeDensity(i) }, label = { Text(stringResource(res)) })
                    }
                }
                SwitchRow(R.string.folders_first, vm.foldersFirst, vm::changeFoldersFirst)
            }

            // ── Shizuku и root ──
            SettingCard(R.string.access_title) {
                Text(stringResource(R.string.access_hint), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Text(stringResource(R.string.shizuku_title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    stringResource(
                        when (Shell.shizuku) {
                            ShizukuState.Unavailable -> R.string.shizuku_unavailable
                            ShizukuState.NotRunning -> R.string.shizuku_not_running
                            ShizukuState.NoPermission -> R.string.shizuku_no_permission
                            ShizukuState.Connecting -> R.string.shizuku_connecting
                            ShizukuState.Connected -> R.string.shizuku_connected
                        },
                    ),
                    color = if (Shell.shizuku == ShizukuState.Connected) cs.primary else cs.onSurfaceVariant,
                )
                WideButton(
                    stringResource(R.string.shell_connect),
                    { Shell.connectShizuku() },
                    enabled = Shell.shizuku != ShizukuState.Unavailable && Shell.shizuku != ShizukuState.Connected,
                )
                WideButton(
                    stringResource(R.string.shizuku_open_app),
                    { Shell.openShizukuApp(context) },
                    tonal = true,
                    enabled = Shell.shizukuInstalled(context),
                )
                // нажатие на строку Root открывает плашку с моделью, ядром и состоянием root
                Row(
                    Modifier
                        .padding(top = 8.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(cs.surfaceContainerHigh)
                        .clickable { vm.dialog = DialogState.RootInfo }
                        .padding(start = 16.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.root_title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            stringResource(
                                when {
                                    !Shell.rootEnabled -> R.string.root_experimental
                                    Shell.rootWorks -> R.string.root_ok
                                    else -> R.string.root_denied
                                },
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (Shell.rootEnabled && Shell.rootWorks) cs.primary else cs.onSurfaceVariant,
                        )
                        Text(stringResource(R.string.root_tap_hint), style = MaterialTheme.typography.labelSmall, color = cs.outline)
                    }
                    Switch(checked = Shell.rootEnabled, onCheckedChange = vm::setRoot)
                }
            }

            // ── О приложении (самый низ) ──
            AboutCard(vm)
        }
    }
}

/** Версия, дата последнего обновления и проверка обновлений. */
@Composable
private fun AboutCard(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val info = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0)
        } catch (_: Exception) {
            null
        }
    }
    val versionName = info?.versionName ?: "?"
    val versionCode = info?.let { androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(it) } ?: 0L
    val updated = info?.lastUpdateTime?.let { formatDate(it) }.orEmpty()
    SettingCard(R.string.about_title) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBlob(Icons.Rounded.Folder, cs.primary, cs.onPrimary, size = 56.dp, corner = 20.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${stringResource(R.string.about_version)} $versionName ($versionCode)", color = cs.onSurfaceVariant)
            }
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.secondaryContainer).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(stringResource(R.string.about_updated), color = cs.onSecondaryContainer, modifier = Modifier.weight(1f))
            Text(updated, fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer)
        }
        WideButton(
            stringResource(R.string.about_check),
            { vm.checkUpdate() },
            enabled = vm.updateState !is Update.State.Checking,
        )
        when (val st = vm.updateState) {
            Update.State.Idle -> Unit
            Update.State.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Text(stringResource(R.string.about_checking))
            }
            Update.State.UpToDate -> StatusBlock(R.string.about_uptodate, cs.primaryContainer, cs.onPrimaryContainer)
            Update.State.Failed -> StatusBlock(R.string.about_failed, cs.errorContainer, cs.onErrorContainer)
            is Update.State.Available -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.tertiaryContainer).padding(14.dp),
                ) {
                    Text(stringResource(R.string.about_available, st.versionName), fontWeight = FontWeight.Bold, color = cs.onTertiaryContainer)
                    if (st.notes.isNotBlank()) Text(st.notes, color = cs.onTertiaryContainer.copy(alpha = 0.85f))
                }
                WideButton(stringResource(R.string.about_open), {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(st.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }, tonal = true)
            }
        }
    }
}

@Composable
private fun StatusBlock(text: Int, container: Color, content: Color) {
    Text(
        stringResource(text),
        color = content,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(container).padding(14.dp),
    )
}

@Composable
private fun SettingCard(title: Int, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(cs.surfaceContainerLow)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(stringResource(title), style = MaterialTheme.typography.titleMedium, color = cs.primary, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun SwitchRow(title: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(title), Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
