package com.mat3files

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Состояние открытого файла в редакторе. Хранится во ViewModel, чтобы пережить поворот экрана. */
class EditorState(val path: String) {
    var loading by mutableStateOf(true)
    var tooBig by mutableStateOf(false)
    var binary by mutableStateOf(false)
    var hex by mutableStateOf("")
    var text by mutableStateOf(TextFieldValue(""))
    var original by mutableStateOf("")
    var wrap by mutableStateOf(false)
    var fontSize by mutableFloatStateOf(14f)
    var searchOpen by mutableStateOf(false)
    var query by mutableStateOf("")
    var replacement by mutableStateOf("")
    var failed by mutableStateOf(false)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)

    private var local: File = File(path)
    private var charset: Charset = Charsets.UTF_8
    private var crlf = false
    private var bom = false
    private var loaded = false
    private var lastPush = 0L
    private val undoStack = ArrayDeque<TextFieldValue>()
    private val redoStack = ArrayDeque<TextFieldValue>()

    val encoding: String get() = charset.displayName()
    val lineEnding: String get() = if (crlf) "CRLF" else "LF"

    /** Вставить текст на место курсора (выделение заменяется); [back] — на сколько символов вернуть курсор назад. */
    fun insert(s: String, back: Int = 0) {
        pushUndo(text)
        lastPush = 0
        redoStack.clear()
        redoCount = 0
        val sel = text.selection
        val t = text.text.replaceRange(sel.min, sel.max, s)
        text = TextFieldValue(t, TextRange(sel.min + s.length - back))
    }

    val dirty: Boolean get() = !loading && !binary && !tooBig && text.text != original

    suspend fun load() {
        if (loaded) return
        loaded = true
        withContext(Dispatchers.IO) {
            if (ShellFs.needsShell(path)) {
                val staged = ShellFs.stage(path)
                if (staged == null) {
                    failed = true
                    return@withContext
                }
                local = staged
            }
            val f = local
            if (f.length() > MAX_BYTES) {
                tooBig = true
                return@withContext
            }
            val bytes = f.readBytes()
            if (bytes.take(8000).any { it == 0.toByte() }) {
                binary = true
                hex = hexDump(bytes)
                return@withContext
            }
            val decoded = decode(bytes)
            crlf = decoded.contains("\r\n")
            val t = if (crlf) decoded.replace("\r\n", "\n") else decoded
            original = t
            text = TextFieldValue(t)
        }
        loading = false
    }

    private fun decode(bytes: ByteArray): String {
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            charset = Charsets.UTF_8
            val s = decoder.decode(ByteBuffer.wrap(bytes)).toString()
            if (s.startsWith("\uFEFF")) {
                bom = true
                s.substring(1)
            } else {
                s
            }
        } catch (_: CharacterCodingException) {
            // не UTF-8 — чаще всего старый русский текст в Windows-1251
            charset = Charset.forName("windows-1251")
            String(bytes, charset)
        }
    }

    private fun hexDump(bytes: ByteArray): String {
        val n = minOf(bytes.size, 16 * 1024)
        val sb = StringBuilder()
        var i = 0
        while (i < n) {
            sb.append("%08X  ".format(i))
            val end = minOf(i + 16, n)
            for (j in i until i + 16) sb.append(if (j < end) "%02X ".format(bytes[j]) else "   ")
            sb.append(' ')
            for (j in i until end) {
                val b = bytes[j].toInt() and 0xFF
                sb.append(if (b in 32..126) b.toChar() else '.')
            }
            sb.append('\n')
            i += 16
        }
        return sb.toString()
    }

    suspend fun save(): Boolean = withContext(Dispatchers.IO) {
        try {
            val body = if (crlf) text.text.replace("\n", "\r\n") else text.text
            local.writeText((if (bom) "\uFEFF" else "") + body, charset)
            if (ShellFs.needsShell(path) && !ShellFs.writeBack(local, path)) return@withContext false
            original = text.text
            true
        } catch (_: Exception) {
            false
        }
    }

    // ── правка, отмена, повтор ──

    fun onChange(v: TextFieldValue) {
        if (v.text != text.text) {
            val now = System.currentTimeMillis()
            // подряд набранные символы объединяем в один шаг отмены
            if (now - lastPush > 600 || undoStack.isEmpty()) pushUndo(text)
            lastPush = now
            redoStack.clear()
            redoCount = 0
        }
        text = v
    }

    private fun pushUndo(v: TextFieldValue) {
        undoStack.addLast(v)
        if (undoStack.size > 100) undoStack.removeFirst()
        undoCount = undoStack.size
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(text)
        text = undoStack.removeLast()
        lastPush = 0
        undoCount = undoStack.size
        redoCount = redoStack.size
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(text)
        text = redoStack.removeLast()
        lastPush = 0
        undoCount = undoStack.size
        redoCount = redoStack.size
    }

    // ── поиск и замена ──

    fun matchCount(): Int {
        if (query.isEmpty()) return 0
        var n = 0
        var i = text.text.indexOf(query, ignoreCase = true)
        while (i >= 0) {
            n++
            i = text.text.indexOf(query, i + query.length, ignoreCase = true)
        }
        return n
    }

    fun findNext(forward: Boolean) {
        if (query.isEmpty()) return
        val t = text.text
        val from = if (forward) text.selection.max else text.selection.min - 1
        var i = if (forward) t.indexOf(query, from, ignoreCase = true) else t.lastIndexOf(query, from, ignoreCase = true)
        if (i < 0) i = if (forward) t.indexOf(query, 0, ignoreCase = true) else t.lastIndexOf(query, t.length, ignoreCase = true)
        if (i >= 0) text = text.copy(selection = TextRange(i, i + query.length))
    }

    fun replaceAll() {
        if (query.isEmpty()) return
        pushUndo(text)
        text = TextFieldValue(text.text.replace(query, replacement, ignoreCase = true))
    }

    companion object {
        const val MAX_BYTES = 5L * 1024 * 1024
    }
}

@Composable
fun EditorScreen(vm: MainViewModel, path: String) {
    val st = vm.editor(path)
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val name = File(path).name
    LaunchedEffect(path) { st.load() }
    var menu by remember { mutableStateOf(false) }

    val editable = !st.binary && !st.tooBig && !st.loading && !st.failed
    val ext = name.substringAfterLast('.', "").uppercase()
    val sel = st.text.selection.start.coerceIn(0, st.text.text.length)
    val subtitle = if (!editable) null else {
        val before = st.text.text.substring(0, sel)
        val line = before.count { it == '\n' } + 1
        val col = sel - (before.lastIndexOf('\n') + 1) + 1
        (if (ext.isNotEmpty()) "$ext · " else "") + stringResource(R.string.editor_pos, line, col) + " · " + st.encoding + " · " + st.lineEnding
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(
            title = name + if (st.dirty) " •" else "",
            subtitle = subtitle,
            onBack = vm::back,
        ) {
            if (editable) {
                IconButton(onClick = { st.searchOpen = !st.searchOpen }) {
                    Icon(Icons.Rounded.Search, null, tint = if (st.searchOpen) cs.primary else cs.onSurfaceVariant)
                }
                FilledIconButton(onClick = { vm.saveEditor(path) {} }, enabled = st.dirty) {
                    Icon(Icons.Rounded.Save, stringResource(R.string.editor_save))
                }
            }
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
            if (menu) EditorMenuDialog(st, onDismiss = { menu = false }, onExternal = { menu = false; openFile(context, path) }, onShare = { menu = false; shareFiles(context, listOf(path)) })
        }
        when {
            st.failed -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.msg_need_shell), color = cs.onSurfaceVariant)
            }
            st.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            st.tooBig -> Message(stringResource(R.string.editor_too_big)) { openFile(context, path) }
            st.binary -> Column(Modifier.fillMaxSize()) {
                Text(
                    stringResource(R.string.editor_binary),
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                Text(
                    st.hex,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp),
                )
            }
            else -> {
                if (st.searchOpen) SearchBar(st)
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(cs.surfaceContainerLowest),
                ) { CodeArea(st, name) }
                EditorToolbar(st)
            }
        }
    }
}

/** Нижняя панель: отмена/повтор и кнопки для символов, которые неудобно искать на экранной клавиатуре. */
@Composable
private fun EditorToolbar(st: EditorState) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(cs.surfaceContainerHigh)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = st::undo, enabled = st.undoCount > 0) { Icon(Icons.AutoMirrored.Rounded.Undo, null) }
        IconButton(onClick = st::redo, enabled = st.redoCount > 0) { Icon(Icons.AutoMirrored.Rounded.Redo, null) }
        VerticalDivider(Modifier.height(24.dp))
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            KeyChip("Tab") { st.insert("    ") }
            listOf("()", "{}", "[]", "\"\"", "''", "<>").forEach { pair -> KeyChip(pair) { st.insert(pair, back = 1) } }
            listOf(";", ":", "=", "/", "\\", "#", "$", "&", "|", "!", "-", "_", "*", "%").forEach { c -> KeyChip(c) { st.insert(c) } }
        }
    }
}

@Composable
private fun KeyChip(label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .padding(horizontal = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(cs.secondaryContainer)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = cs.onSecondaryContainer)
    }
}

@Composable
private fun Message(text: String, onOpen: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = onOpen, modifier = Modifier.padding(top = 16.dp)) { Text(stringResource(R.string.editor_open_external)) }
    }
}

@Composable
private fun SearchBar(st: EditorState) {
    val cs = MaterialTheme.colorScheme
    val colors = TextFieldDefaults.colors(
        focusedContainerColor = cs.surfaceContainerHigh,
        unfocusedContainerColor = cs.surfaceContainerHigh,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
    )
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = st.query,
                onValueChange = { st.query = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.editor_find)) },
                shape = RoundedCornerShape(20.dp),
                colors = colors,
                modifier = Modifier.weight(1f),
            )
            Text(
                st.matchCount().toString(),
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
            IconButton(onClick = { st.findNext(false) }) { Icon(Icons.Rounded.KeyboardArrowUp, null) }
            IconButton(onClick = { st.findNext(true) }) { Icon(Icons.Rounded.KeyboardArrowDown, null) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
            TextField(
                value = st.replacement,
                onValueChange = { st.replacement = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.editor_replace)) },
                shape = RoundedCornerShape(20.dp),
                colors = colors,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = st::replaceAll, enabled = st.query.isNotEmpty()) {
                Text(stringResource(R.string.editor_replace_all))
            }
        }
    }
}

@Composable
private fun CodeArea(st: EditorState, fileName: String) {
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val family = remember(fileName) { Highlighter.familyOf(fileName) }
    val colors = SyntaxColors(cs.primary, cs.tertiary, cs.outline, cs.secondary, cs.primary)
    val transformation = remember(family, colors) {
        VisualTransformation { input ->
            TransformedText(Highlighter.highlight(input.text, family, colors), OffsetMapping.Identity)
        }
    }
    val lineHeight = (st.fontSize * 1.45f).sp
    val style = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = st.fontSize.sp,
        lineHeight = lineHeight,
        color = cs.onSurface,
    )
    val lines = st.text.text.count { it == '\n' } + 1
    val gutter = remember(lines) { (1..lines).joinToString("\n") }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()

    // при поиске прокручиваем к найденному месту
    val selectionStart = st.text.selection.start
    LaunchedEffect(selectionStart, st.searchOpen) {
        if (st.searchOpen && st.query.isNotEmpty() && !st.text.selection.collapsed) {
            val line = st.text.text.take(selectionStart).count { it == '\n' }
            val lineHeightPx = with(density) { lineHeight.toPx() }
            vScroll.animateScrollTo((line * lineHeightPx - 120f).toInt().coerceAtLeast(0))
        }
    }

    Row(Modifier.fillMaxSize().verticalScroll(vScroll)) {
        if (!st.wrap) {
            Text(
                gutter,
                style = style.copy(color = cs.onSurfaceVariant.copy(alpha = 0.55f), textAlign = TextAlign.End),
                modifier = Modifier
                    .background(cs.surfaceContainerLow)
                    .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 120.dp),
            )
        }
        Box(Modifier.weight(1f).then(if (st.wrap) Modifier else Modifier.horizontalScroll(hScroll))) {
            BasicTextField(
                value = st.text,
                onValueChange = st::onChange,
                textStyle = style,
                cursorBrush = SolidColor(cs.primary),
                visualTransformation = transformation,
                modifier = Modifier
                    .defaultMinSize(minWidth = 280.dp, minHeight = 300.dp)
                    .padding(start = 10.dp, end = 16.dp, top = 8.dp, bottom = 120.dp),
            )
        }
    }
}


/** Меню редактора в общем стиле приложения: крупные скруглённые строки с цветными значками. */
@Composable
private fun EditorMenuDialog(st: EditorState, onDismiss: () -> Unit, onExternal: () -> Unit, onShare: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        androidx.compose.material3.Surface(
            shape = RoundedCornerShape(36.dp),
            color = cs.surfaceContainerHigh,
            modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
        ) {
            Column(Modifier.padding(vertical = 16.dp)) {
                MenuRow(Icons.AutoMirrored.Rounded.ViewList, 0, stringResource(R.string.editor_wrap), onClick = { st.wrap = !st.wrap }) {
                    androidx.compose.material3.Switch(checked = st.wrap, onCheckedChange = { st.wrap = it })
                }
                MenuRow(Icons.Rounded.TextFields, 1, stringResource(R.string.editor_font_size), onClick = {}) {
                    androidx.compose.material3.FilledTonalIconButton(onClick = { st.fontSize = (st.fontSize - 1f).coerceAtLeast(9f) }) {
                        Icon(Icons.Rounded.Remove, stringResource(R.string.editor_font_down))
                    }
                    Text(
                        st.fontSize.toInt().toString(),
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp),
                    )
                    androidx.compose.material3.FilledTonalIconButton(onClick = { st.fontSize = (st.fontSize + 1f).coerceAtMost(28f) }) {
                        Icon(Icons.Rounded.Add, stringResource(R.string.editor_font_up))
                    }
                }
                androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 8.dp, horizontal = 22.dp))
                MenuRow(Icons.Rounded.Link, 2, stringResource(R.string.editor_open_external), onClick = onExternal)
                MenuRow(Icons.Rounded.Share, 3, stringResource(R.string.act_share), onClick = onShare)
            }
        }
    }
}

@Composable
private fun MenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colorIndex: Int,
    label: String,
    onClick: () -> Unit,
    trailing: @Composable (androidx.compose.foundation.layout.RowScope.() -> Unit)? = null,
) {
    val (bg, fg) = blobColors(colorIndex)
    Row(
        Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBlob(icon, bg, fg, 40.dp, 14.dp)
        Spacer(Modifier.width(16.dp))
        Text(label, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, modifier = Modifier.weight(1f))
        trailing?.invoke(this)
    }
}
