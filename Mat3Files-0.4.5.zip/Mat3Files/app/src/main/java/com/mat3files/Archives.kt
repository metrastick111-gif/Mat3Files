package com.mat3files

import kotlinx.coroutines.ensureActive
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.charset.Charset
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.coroutines.coroutineContext

enum class ArchiveFormat(val ext: String, val label: String, val canCreate: Boolean) {
    Zip(".zip", "ZIP", true),
    SevenZ(".7z", "7z", true),
    TarGz(".tar.gz", "TAR.GZ", true),
    Tar(".tar", "TAR", false),
}

/** Создание и распаковка архивов zip, 7z, tar и tar.gz. */
object Archives {
    fun formatOf(name: String): ArchiveFormat? {
        val n = name.lowercase()
        return when {
            n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".apk") -> ArchiveFormat.Zip
            n.endsWith(".7z") -> ArchiveFormat.SevenZ
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> ArchiveFormat.TarGz
            n.endsWith(".tar") -> ArchiveFormat.Tar
            else -> null
        }
    }

    /** Имя без расширения архива: «фото.tar.gz» → «фото». */
    fun baseName(name: String): String {
        val n = name.lowercase()
        val cut = listOf(".tar.gz", ".tgz", ".tar", ".zip", ".jar", ".7z").firstOrNull { n.endsWith(it) }
        return if (cut != null) name.dropLast(cut.length) else name.substringBeforeLast('.')
    }

    // ───────── создание ─────────

    private fun flatten(sources: List<File>): List<Pair<File, String>> {
        val out = ArrayList<Pair<File, String>>()
        for (root in sources) {
            val base = root.parentFile ?: continue
            root.walkTopDown().forEach { f -> out.add(f to f.relativeTo(base).invariantSeparatorsPath) }
        }
        return out
    }

    suspend fun compress(sources: List<File>, dest: File, format: ArchiveFormat, onBytes: (Long) -> Unit) {
        val entries = flatten(sources)
        when (format) {
            ArchiveFormat.Zip -> writeZip(entries, dest, onBytes)
            ArchiveFormat.SevenZ -> writeSevenZ(entries, dest, onBytes)
            ArchiveFormat.TarGz -> writeTarGz(entries, dest, onBytes)
            ArchiveFormat.Tar -> throw IOException("TAR creation is not supported")
        }
    }

    private suspend fun writeZip(entries: List<Pair<File, String>>, dest: File, onBytes: (Long) -> Unit) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(dest))).use { zos ->
            for ((file, name) in entries) {
                coroutineContext.ensureActive()
                if (file.isDirectory) {
                    zos.putNextEntry(ZipEntry("$name/"))
                    zos.closeEntry()
                } else {
                    val e = ZipEntry(name)
                    e.time = file.lastModified()
                    zos.putNextEntry(e)
                    FileInputStream(file).use { input -> pump(input, onBytes) { b, n -> zos.write(b, 0, n) } }
                    zos.closeEntry()
                }
            }
        }
    }

    private suspend fun writeSevenZ(entries: List<Pair<File, String>>, dest: File, onBytes: (Long) -> Unit) {
        SevenZOutputFile(dest).use { out ->
            for ((file, name) in entries) {
                coroutineContext.ensureActive()
                val entry = out.createArchiveEntry(file, if (file.isDirectory) "$name/" else name)
                out.putArchiveEntry(entry)
                if (file.isFile) {
                    FileInputStream(file).use { input -> pump(input, onBytes) { b, n -> out.write(b, 0, n) } }
                }
                out.closeArchiveEntry()
            }
            out.finish()
        }
    }

    private suspend fun writeTarGz(entries: List<Pair<File, String>>, dest: File, onBytes: (Long) -> Unit) {
        val raw = BufferedOutputStream(FileOutputStream(dest))
        TarArchiveOutputStream(GzipCompressorOutputStream(raw)).use { tar ->
            tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
            tar.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
            for ((file, name) in entries) {
                coroutineContext.ensureActive()
                tar.putArchiveEntry(TarArchiveEntry(file, name))
                if (file.isFile) {
                    FileInputStream(file).use { input -> pump(input, onBytes) { b, n -> tar.write(b, 0, n) } }
                }
                tar.closeArchiveEntry()
            }
            tar.finish()
        }
    }

    private suspend fun pump(input: InputStream, onBytes: (Long) -> Unit, write: (ByteArray, Int) -> Unit) {
        val buf = ByteArray(128 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            write(buf, n)
            onBytes(n.toLong())
            coroutineContext.ensureActive()
        }
    }

    // ───────── распаковка ─────────

    /** Защита от «zip slip»: запись не должна выйти за пределы целевой папки. */
    private fun safeTarget(dest: File, name: String): File {
        val target = File(dest, name)
        val root = dest.canonicalPath
        val path = target.canonicalPath
        if (path != root && !path.startsWith(root + File.separator)) throw IOException("Unsafe entry: $name")
        return target
    }

    private fun openZip(file: File): ZipFile =
        try {
            ZipFile(file)
        } catch (_: Exception) {
            // старые архивы с русскими именами часто в кодировке CP866
            ZipFile(file, Charset.forName("IBM866"))
        }

    suspend fun extract(archive: File, destDir: File, onBytes: (Long) -> Unit) {
        destDir.mkdirs()
        when (formatOf(archive.name)) {
            ArchiveFormat.Zip -> extractZip(archive, destDir, onBytes)
            ArchiveFormat.SevenZ -> extractSevenZ(archive, destDir, onBytes)
            ArchiveFormat.TarGz -> extractTar(archive, destDir, true, onBytes)
            ArchiveFormat.Tar -> extractTar(archive, destDir, false, onBytes)
            null -> throw IOException("Unknown archive")
        }
    }

    private suspend fun extractZip(archive: File, dest: File, onBytes: (Long) -> Unit) {
        openZip(archive).use { zip ->
            val en = zip.entries()
            while (en.hasMoreElements()) {
                coroutineContext.ensureActive()
                val e = en.nextElement()
                val target = safeTarget(dest, e.name)
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    zip.getInputStream(e).use { input ->
                        FileOutputStream(target).use { out -> pump(input, onBytes) { b, n -> out.write(b, 0, n) } }
                    }
                    if (e.time > 0) target.setLastModified(e.time)
                }
            }
        }
    }

    private suspend fun extractSevenZ(archive: File, dest: File, onBytes: (Long) -> Unit) {
        SevenZFile(archive).use { sz ->
            var e = sz.nextEntry
            val buf = ByteArray(128 * 1024)
            while (e != null) {
                coroutineContext.ensureActive()
                val target = safeTarget(dest, e.name)
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out ->
                        while (true) {
                            val n = sz.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            onBytes(n.toLong())
                            coroutineContext.ensureActive()
                        }
                    }
                }
                e = sz.nextEntry
            }
        }
    }

    private suspend fun extractTar(archive: File, dest: File, gz: Boolean, onBytes: (Long) -> Unit) {
        val raw = BufferedInputStream(FileInputStream(archive))
        val stream: InputStream = if (gz) GzipCompressorInputStream(raw) else raw
        TarArchiveInputStream(stream).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                coroutineContext.ensureActive()
                val target = safeTarget(dest, e.name)
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out -> pump(tar, onBytes) { b, n -> out.write(b, 0, n) } }
                }
                e = tar.nextEntry
            }
        }
    }

    // ───────── просмотр содержимого ─────────

    data class Entry(val name: String, val size: Long, val isDir: Boolean, val time: Long = 0L)

    /** Содержимое архива (не больше [limit] записей) и общий размер. */
    fun list(archive: File, limit: Int = 300): Pair<List<Entry>, Long> {
        val out = ArrayList<Entry>()
        var total = 0L
        when (formatOf(archive.name)) {
            ArchiveFormat.Zip -> openZip(archive).use { zip ->
                val en = zip.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    total += maxOf(e.size, 0L)
                    if (out.size < limit) out.add(Entry(e.name, e.size, e.isDirectory, e.time))
                }
            }
            ArchiveFormat.SevenZ -> SevenZFile(archive).use { sz ->
                for (e in sz.entries) {
                    total += maxOf(e.size, 0L)
                    val t = try { e.lastModifiedDate?.time ?: 0L } catch (_: Exception) { 0L }
                    if (out.size < limit) out.add(Entry(e.name, e.size, e.isDirectory, t))
                }
            }
            ArchiveFormat.TarGz, ArchiveFormat.Tar -> {
                val raw = BufferedInputStream(FileInputStream(archive))
                val stream: InputStream = if (formatOf(archive.name) == ArchiveFormat.TarGz) GzipCompressorInputStream(raw) else raw
                TarArchiveInputStream(stream).use { tar ->
                    var e = tar.nextEntry
                    while (e != null) {
                        total += maxOf(e.size, 0L)
                        if (out.size < limit) out.add(Entry(e.name, e.size, e.isDirectory, e.modTime?.time ?: 0L))
                        e = tar.nextEntry
                    }
                }
            }
            null -> Unit
        }
        return out to total
    }

    // ───────── просмотр внутри архива без распаковки ─────────

    data class VItem(val name: String, val isDir: Boolean, val size: Long, val time: Long, val fullName: String)

    /** Содержимое «папки» [inner] внутри архива: [inner] — путь вида «src/main/». */
    fun children(entries: List<Entry>, inner: String): List<VItem> {
        val map = LinkedHashMap<String, VItem>()
        for (e in entries) {
            val n = e.name.removePrefix("./")
            if (n.length <= inner.length || !n.startsWith(inner)) continue
            val rest = n.substring(inner.length)
            val seg = rest.substringBefore('/')
            if (seg.isEmpty()) continue
            val isDir = rest.contains('/') || e.isDir
            if (map.containsKey(seg)) continue
            map[seg] = VItem(seg, isDir, if (isDir) 0L else e.size, e.time, inner + seg + if (isDir) "/" else "")
        }
        return map.values.sortedWith(compareByDescending<VItem> { it.isDir }.thenBy { it.name.lowercase() })
    }

    /** Достать один файл из архива в [dest] (для просмотра без полной распаковки). */
    fun extractEntry(archive: File, entryName: String, dest: File) {
        dest.parentFile?.mkdirs()
        when (formatOf(archive.name)) {
            ArchiveFormat.Zip -> openZip(archive).use { zip ->
                val e = zip.getEntry(entryName) ?: zip.getEntry("./$entryName") ?: throw IOException("No entry")
                zip.getInputStream(e).use { input -> FileOutputStream(dest).use { out -> input.copyTo(out) } }
            }
            ArchiveFormat.SevenZ -> SevenZFile(archive).use { sz ->
                var e = sz.nextEntry
                while (e != null) {
                    if (e.name.removePrefix("./") == entryName && !e.isDirectory) {
                        FileOutputStream(dest).use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = sz.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                            }
                        }
                        return
                    }
                    e = sz.nextEntry
                }
                throw IOException("No entry")
            }
            ArchiveFormat.TarGz, ArchiveFormat.Tar -> {
                val raw = BufferedInputStream(FileInputStream(archive))
                val stream: InputStream = if (formatOf(archive.name) == ArchiveFormat.TarGz) GzipCompressorInputStream(raw) else raw
                TarArchiveInputStream(stream).use { tar ->
                    var e = tar.nextEntry
                    while (e != null) {
                        if (e.name.removePrefix("./") == entryName && !e.isDirectory) {
                            FileOutputStream(dest).use { out -> tar.copyTo(out) }
                            return
                        }
                        e = tar.nextEntry
                    }
                }
                throw IOException("No entry")
            }
            null -> throw IOException("Unknown archive")
        }
    }
}
