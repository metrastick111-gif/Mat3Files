package com.mat3files

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ───────────────────────── Поиск ─────────────────────────

@Composable
fun SearchScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    // папка, из которой открыли поиск
    val hereFolder = remember { vm.stack.lastOrNull { it is Screen.Folder } as? Screen.Folder }

    val results by produceState(emptyList<FileItem>(), vm.searchQuery, vm.searchHere, vm.searchKind, vm.index) {
        val q = vm.searchQuery.trim()
        value = if (q.isEmpty()) {
            emptyList()
        } else {
            withContext(Dispatchers.Default) {
                val found = if (vm.searchHere && hereFolder != null && !ShellFs.needsShell(hereFolder.path)) {
                    File(hereFolder.path).walkTopDown().maxDepth(12)
                        .filter { it.name.contains(q, ignoreCase = true) && it.path != hereFolder.path }
                        .take(400)
                        .map { f ->
                            val dir = f.isDirectory
                            FileItem(f.absolutePath, f.name, dir, if (dir) 0 else f.length(), f.lastModified(), kindOf(f.name, dir))
                        }
                        .toList()
                } else {
                    vm.index.filter { it.name.contains(q, ignoreCase = true) }.sortedByDescending { it.modified }.take(400)
                }
                found.filter { vm.searchKind == null || it.kind == vm.searchKind }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.act_back)) }
            TextField(
                value = vm.searchQuery,
                onValueChange = { vm.searchQuery = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                trailingIcon = {
                    if (vm.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { vm.searchQuery = "" }) { Icon(Icons.Rounded.Clear, null) }
                    }
                },
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = cs.surfaceContainerHigh,
                    unfocusedContainerColor = cs.surfaceContainerHigh,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.weight(1f).focusRequester(focus).padding(end = 12.dp),
            )
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
        ) {
            item {
                FilterChip(selected = !vm.searchHere, onClick = { vm.searchHere = false }, label = { Text(stringResource(R.string.search_everywhere)) })
            }
            item {
                FilterChip(selected = vm.searchHere, onClick = { vm.searchHere = true }, label = { Text(stringResource(R.string.search_here)) })
            }
            val kinds = listOf(
                R.string.filter_all to null,
                R.string.sec_images to Kind.Image,
                R.string.sec_videos to Kind.Video,
                R.string.sec_audio to Kind.Audio,
                R.string.sec_docs to Kind.Doc,
                R.string.filter_code to Kind.Code,
                R.string.sec_archives to Kind.Archive,
                R.string.sec_apks to Kind.Apk,
            )
            items(kinds) { (res, kind) ->
                FilterChip(selected = vm.searchKind == kind, onClick = { vm.searchKind = kind }, label = { Text(stringResource(res)) })
            }
        }
        Spacer(Modifier.padding(top = 4.dp))
        when {
            vm.searchQuery.isBlank() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.search_empty_hint), color = cs.onSurfaceVariant)
            }
            results.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.empty_search), color = cs.onSurfaceVariant)
            }
            else -> {
                Text(
                    stringResource(R.string.search_found, results.size),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.primary,
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp),
                )
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 24.dp)) {
                    items(results, key = { it.path }) { item ->
                        Row(
                            Modifier
                                .animateItem()
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { openItem(vm, context, item, results) }
                                .padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            FileThumb(item, 44.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                MiddleEllipsisText(item.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                Text(
                                    File(item.path).parent.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(onClick = { vm.openContaining(item.path) }) {
                                Icon(Icons.Rounded.FolderOpen, stringResource(R.string.search_open_folder), tint = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Просмотр архива без распаковки ─────────────────────────

@Composable
fun ArchiveViewScreen(vm: MainViewModel, path: String, inner: String) {
    val cs = MaterialTheme.colorScheme
    val file = File(path)
    val loaded by produceState<Result<List<Archives.Entry>>?>(null, path) {
        value = runCatching { vm.archiveEntries(path) }
    }
    val title = inner.trimEnd('/').substringAfterLast('/').ifEmpty { file.name }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = title,
            subtitle = file.name + if (inner.isNotEmpty()) " › " + inner.trimEnd('/') else "",
            onBack = vm::back,
        ) {
            IconButton(onClick = { vm.extract(path, file.parent.orEmpty(), subfolder = true) }) {
                Icon(Icons.Rounded.Unarchive, stringResource(R.string.archive_extract_all))
            }
        }
        val result = loaded
        when {
            result == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            result.isFailure -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.archive_error), color = cs.error)
            }
            else -> {
                val rows = remember(result, inner) { Archives.children(result.getOrThrow(), inner) }
                if (rows.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(stringResource(R.string.empty_folder), color = cs.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp)) {
                        items(rows, key = { it.fullName }) { row ->
                            val kind = kindOf(row.name, row.isDir)
                            val (bg, fg) = kindColors(kind)
                            Row(
                                Modifier
                                    .animateItem()
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable {
                                        if (row.isDir) vm.push(Screen.ArchiveView(path, row.fullName))
                                        else vm.openArchiveEntry(path, row.fullName)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(bg),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(if (row.isDir) Icons.Rounded.Folder else kindIcon(kind), null, tint = fg) }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    MiddleEllipsisText(row.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                    Text(
                                        (if (row.isDir) stringResource(R.string.folder_label) else formatSize(row.size)) +
                                            (if (row.time > 0) " · " + formatDate(row.time) else ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = cs.onSurfaceVariant,
                                        maxLines = 1,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
