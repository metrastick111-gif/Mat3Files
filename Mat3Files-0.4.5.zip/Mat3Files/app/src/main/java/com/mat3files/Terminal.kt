package com.mat3files

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Terminal
import android.content.Intent
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

/** Строка вывода: 0 — команда, 1 — вывод, 2 — сообщение, 3 — ошибка. */
data class TermLine(val text: String, val kind: Int)

/** Сеанс терминала. Живёт во ViewModel, поэтому вывод не пропадает при переходах между экранами. */
class TerminalSession(private val context: Context, private val scope: CoroutineScope) {
    val lines = mutableStateListOf<TermLine>()
    var cwd by mutableStateOf("/storage/emulated/0")
    /** 0 — приложение, 1 — Shizuku, 2 — Root. */
    var mode by mutableIntStateOf(0)
    var input by mutableStateOf("")
    var running by mutableStateOf(false)
        private set

    /** Незавершённая строка вывода (приглашение вроде «Ваш выбор: » без перевода строки). */
    var partial by mutableStateOf("")
        private set

    private val history = ArrayList<String>()
    private var historyIndex = 0
    private var job: Job? = null
    @Volatile private var process: Process? = null
    @Volatile private var svcId = -1
    private val pending = StringBuilder()

    /** Принять кусок вывода: целые строки — в список, хвост без \n — в [partial]. */
    private fun feed(chunk: String) = synchronized(pending) {
        pending.append(chunk.replace("\r\n", "\n").replace('\r', '\n'))
        while (true) {
            val nl = pending.indexOf("\n")
            if (nl < 0) break
            add(pending.substring(0, nl), 1)
            pending.delete(0, nl + 1)
        }
        partial = pending.toString()
    }

    private fun flushPartial() = synchronized(pending) {
        if (pending.isNotEmpty()) add(pending.toString(), 1)
        pending.setLength(0)
        partial = ""
    }

    /** Ответ программе, которая сейчас работает (read в скрипте, меню, пароль и т.п.). */
    private fun sendInput(text: String) {
        synchronized(pending) {
            add(partial + text, 0)
            pending.setLength(0)
            partial = ""
        }
        val line = text + "\n"
        scope.launch(Dispatchers.IO) {
            try {
                if (mode == 1) {
                    Shell.svcWrite(svcId, line)
                } else {
                    process?.outputStream?.let {
                        it.write(line.toByteArray())
                        it.flush()
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    init {
        add(context.getString(R.string.term_welcome), 2)
    }

    fun add(text: String, kind: Int) {
        lines.add(TermLine(text, kind))
        if (lines.size > 3000) repeat(500) { lines.removeAt(0) }
    }

    fun clear() = lines.clear()

    fun historyUp() {
        if (history.isEmpty()) return
        historyIndex = (historyIndex - 1).coerceAtLeast(0)
        input = history[historyIndex]
    }

    /** Запустить файл .sh в его папке выбранным способом. */
    fun runFile(path: String, newMode: Int) {
        mode = newMode
        cwd = File(path).parent ?: "/"
        run("sh " + ShellFs.q(path))
    }

    fun run(raw: String) {
        if (running) {
            sendInput(raw)
            return
        }
        val cmd = raw.trim()
        if (cmd.isEmpty()) return
        history.add(cmd)
        historyIndex = history.size
        add(cwd + " $ " + cmd, 0)
        when {
            cmd == "clear" -> clear()
            cmd == "cd" || cmd.startsWith("cd ") -> changeDir(cmd.removePrefix("cd").trim())
            else -> execute(cmd)
        }
    }

    private fun changeDir(arg: String) {
        val raw = if (arg.isBlank() || arg == "~") "/storage/emulated/0" else arg
        val abs = if (raw.startsWith("/")) raw else cwd.trimEnd('/') + "/" + raw
        val target = java.nio.file.Paths.get(abs).normalize().toString().ifEmpty { "/" }
        scope.launch(Dispatchers.IO) {
            val test = "[ -d ${ShellFs.q(target)} ] && echo 1"
            val ok = when (mode) {
                2 -> Shell.execRoot(test)?.second?.trim() == "1"
                1 -> Shell.execService(test)?.second?.trim() == "1"
                else -> File(target).isDirectory
            }
            if (ok) cwd = target else add("cd: $target: " + context.getString(R.string.term_no_dir), 3)
        }
    }

    private fun execute(cmd: String) {
        if (mode == 1 && !Shell.available) {
            add(context.getString(R.string.term_no_shizuku), 3)
            return
        }
        if (mode == 2 && !Shell.rootReady) {
            add(context.getString(R.string.term_no_root), 3)
            return
        }
        running = true
        pending.setLength(0)
        partial = ""
        job = scope.launch(Dispatchers.IO) {
            try {
                if (mode == 1) {
                    val id = Shell.svcStart("cd " + ShellFs.q(cwd) + " 2>/dev/null; " + cmd)
                    if (id == null) {
                        add(context.getString(R.string.term_no_shizuku), 3)
                    } else {
                        svcId = id
                        var code = "-1"
                        while (true) {
                            val chunk = Shell.svcRead(id) ?: break
                            if (chunk.startsWith("\u0000")) {
                                code = chunk.substring(1)
                                break
                            }
                            feed(chunk)
                        }
                        flushPartial()
                        add("[exit $code]", 2)
                    }
                } else {
                    val p = Shell.startProcess(cmd, cwd, root = mode == 2)
                    process = p
                    val reader = p.inputStream.reader(Charsets.UTF_8)
                    val buf = CharArray(2048)
                    try {
                        while (true) {
                            val n = reader.read(buf)
                            if (n < 0) break
                            feed(String(buf, 0, n))
                        }
                    } catch (_: java.io.IOException) {
                        // поток закрыт вместе с процессом: это обычное завершение, а не ошибка
                    }
                    flushPartial()
                    add("[exit ${p.waitFor()}]", 2)
                }
            } catch (e: CancellationException) {
                process?.destroy()
                flushPartial()
                throw e
            } catch (e: Exception) {
                flushPartial()
                add(e.message ?: "error", 3)
            } finally {
                process = null
                svcId = -1
                running = false
            }
        }
    }

    fun stop() {
        process?.destroy()
        val id = svcId
        if (id >= 0) Thread { Shell.svcKill(id) }.start()
        job?.cancel()
        add("^C", 2)
    }
}

@Composable
fun TerminalScreen(vm: MainViewModel) {
    val t = vm.terminal
    val cs = MaterialTheme.colorScheme
    val listState = rememberLazyListState()
    val context = LocalContext.current
    LaunchedEffect(t.lines.size, t.partial) {
        val total = t.lines.size + if (t.partial.isNotEmpty()) 1 else 0
        if (total > 0) listState.scrollToItem(total - 1)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(stringResource(R.string.terminal_title), t.cwd, vm::back) {
            if (t.running) {
                IconButton(onClick = t::stop) { Icon(Icons.Rounded.Stop, stringResource(R.string.terminal_stop)) }
            }
            IconButton(onClick = {
                val intent = context.packageManager.getLaunchIntentForPackage("com.termux")
                if (intent != null) context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                else Toast.makeText(context, R.string.term_no_termux, Toast.LENGTH_SHORT).show()
            }) { Icon(Icons.Rounded.Terminal, stringResource(R.string.term_open_termux)) }
            IconButton(onClick = t::clear) { Icon(Icons.Rounded.DeleteSweep, stringResource(R.string.terminal_clear)) }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            FilterChip(selected = t.mode == 0, onClick = { t.mode = 0 }, label = { Text(stringResource(R.string.term_mode_app)) })
            FilterChip(
                selected = t.mode == 1,
                enabled = Shell.available,
                onClick = { t.mode = 1 },
                label = { Text("Shizuku") },
            )
            FilterChip(
                selected = t.mode == 2,
                enabled = Shell.rootReady,
                onClick = { t.mode = 2 },
                label = { Text("Root") },
            )
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(cs.surfaceContainerLowest),
        ) {
            LazyColumn(state = listState, contentPadding = PaddingValues(14.dp), modifier = Modifier.fillMaxSize()) {
                items(t.lines.size) { i ->
                    val line = t.lines[i]
                    Text(
                        line.text,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = if (line.kind == 0) FontWeight.Bold else FontWeight.Normal,
                        color = when (line.kind) {
                            0 -> cs.primary
                            2 -> cs.tertiary
                            3 -> cs.error
                            else -> cs.onSurface
                        },
                    )
                }
                if (t.partial.isNotEmpty()) {
                    item {
                        Text(t.partial, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = cs.onSurface)
                    }
                }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf("ls -la", "pwd", "id", "df -h", "cd ..").forEach { c ->
                FilterChip(selected = false, onClick = { t.input = c }, label = { Text(c, fontFamily = FontFamily.Monospace) })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            IconButton(onClick = t::historyUp) { Icon(Icons.Rounded.ArrowUpward, stringResource(R.string.terminal_history)) }
            TextField(
                value = t.input,
                onValueChange = { t.input = it },
                singleLine = true,
                placeholder = { Text(stringResource(if (t.running) R.string.terminal_hint_input else R.string.terminal_hint)) },
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                shape = RoundedCornerShape(26.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    t.run(t.input)
                    t.input = ""
                }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = cs.surfaceContainerHigh,
                    unfocusedContainerColor = cs.surfaceContainerHigh,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.weight(1f),
            )
            FilledIconButton(
                onClick = {
                    t.run(t.input)
                    t.input = ""
                },
                modifier = Modifier.size(52.dp),
            ) {
                Icon(Icons.AutoMirrored.Rounded.Send, null)
            }
        }
    }
}
