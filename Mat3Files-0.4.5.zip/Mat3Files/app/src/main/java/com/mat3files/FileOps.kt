package com.mat3files

import kotlinx.coroutines.ensureActive
import java.io.File
import kotlin.coroutines.coroutineContext

/** Операции над файлами. Всё выполняется вне главного потока и умеет отменяться. */
object FileOps {
    fun list(path: String, showHidden: Boolean): List<FileItem> {
        val files = File(path).listFiles() ?: return emptyList()
        return files.asSequence()
            .filter { showHidden || !it.name.startsWith(".") }
            .map { f ->
                val dir = f.isDirectory
                FileItem(
                    path = f.absolutePath,
                    name = f.name,
                    isDir = dir,
                    size = if (dir) 0 else f.length(),
                    modified = f.lastModified(),
                    kind = kindOf(f.name, dir),
                    children = if (dir) (f.list()?.size ?: 0) else 0,
                )
            }
            .toList()
    }

    /** Похож ли файл на текстовый: в первых килобайтах нет нулевых байтов. */
    fun looksLikeText(path: String): Boolean = try {
        File(path).inputStream().use { input ->
            val buf = ByteArray(4096)
            val n = input.read(buf)
            n <= 0 || (0 until n).none { buf[it] == 0.toByte() }
        }
    } catch (_: Exception) {
        false
    }

    fun totalSize(f: File): Long =
        if (f.isDirectory) (f.listFiles()?.sumOf { totalSize(it) } ?: 0L) else f.length()

    /** Имя, которого ещё нет в папке: «файл (1).txt». */
    fun uniqueTarget(dir: File, name: String): File {
        var target = File(dir, name)
        if (!target.exists()) return target
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (target.exists()) {
            target = File(dir, "$base ($i)$ext")
            i++
        }
        return target
    }

    fun isInside(parent: File, child: File): Boolean {
        val p = parent.canonicalPath
        val c = child.canonicalPath
        return c == p || c.startsWith("$p/")
    }

    suspend fun copyTree(src: File, dest: File, onBytes: (Long) -> Unit) {
        coroutineContext.ensureActive()
        if (src.isDirectory) {
            dest.mkdirs()
            src.listFiles()?.forEach { copyTree(it, File(dest, it.name), onBytes) }
        } else {
            src.inputStream().use { input ->
                dest.outputStream().use { output ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        onBytes(n.toLong())
                        coroutineContext.ensureActive()
                    }
                }
            }
            dest.setLastModified(src.lastModified())
        }
    }

    /** Перемещение: сначала быстрое переименование, при неудаче (другой диск) — копирование и удаление. */
    suspend fun moveTree(src: File, dest: File, onBytes: (Long) -> Unit) {
        if (src.renameTo(dest)) {
            onBytes(totalSize(dest))
            return
        }
        copyTree(src, dest, onBytes)
        src.deleteRecursively()
    }
}
