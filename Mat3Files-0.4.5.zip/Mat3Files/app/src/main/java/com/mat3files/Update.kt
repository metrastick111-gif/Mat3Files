package com.mat3files

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Проверка обновлений. Приложение скачивает небольшой файл update.json по адресу [UPDATE_URL] и сравнивает
 * номер версии. Формат: {"versionCode": 5, "versionName": "0.5.0", "notes": "что нового", "url": "https://t.me/mat3files"}.
 * Положите такой файл на GitHub (или любой хостинг) и поменяйте адрес ниже.
 */
object Update {
    const val UPDATE_URL = "https://raw.githubusercontent.com/mat3files/mat3files/main/update.json"
    const val TELEGRAM_URL = "https://t.me/mat3files"

    sealed interface State {
        data object Idle : State
        data object Checking : State
        data object UpToDate : State
        data class Available(val versionName: String, val notes: String, val url: String) : State
        data object Failed : State
    }

    suspend fun check(currentCode: Long): State = withContext(Dispatchers.IO) {
        try {
            val conn = URL(UPDATE_URL).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 6000
                conn.readTimeout = 8000
                conn.setRequestProperty("User-Agent", "Mat3Files")
                if (conn.responseCode != 200) return@withContext State.Failed
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val code = json.getLong("versionCode")
                if (code > currentCode) {
                    State.Available(
                        json.optString("versionName", code.toString()),
                        json.optString("notes", ""),
                        json.optString("url", TELEGRAM_URL),
                    )
                } else {
                    State.UpToDate
                }
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            State.Failed
        }
    }
}
