package com.mat3files

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle

data class SyntaxColors(val keyword: Color, val string: Color, val comment: Color, val number: Color, val tag: Color)

/** Простая подсветка синтаксиса на регулярных выражениях: комментарии, строки, числа, ключевые слова, теги. */
object Highlighter {
    enum class Family { Plain, CLike, Hash, Markup }

    private val CLIKE_EXT = setOf(
        "kt", "kts", "java", "c", "h", "cpp", "hpp", "cs", "js", "ts", "jsx", "tsx", "go", "rs", "swift",
        "dart", "php", "gradle", "json", "css", "smali",
    )
    private val HASH_EXT = setOf(
        "py", "sh", "yml", "yaml", "properties", "toml", "ini", "cfg", "conf", "gitignore", "env", "rb", "pl", "ps1", "r", "lua",
    )
    private val MARKUP_EXT = setOf("xml", "html", "htm", "svg", "vue")

    fun familyOf(name: String): Family {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            in CLIKE_EXT -> Family.CLike
            in HASH_EXT -> Family.Hash
            in MARKUP_EXT -> Family.Markup
            else -> Family.Plain
        }
    }

    private val keywords = setOf(
        "fun", "val", "var", "class", "object", "interface", "if", "else", "when", "for", "while", "do", "return",
        "break", "continue", "import", "package", "private", "public", "protected", "internal", "static", "final",
        "void", "int", "long", "double", "float", "boolean", "char", "byte", "short", "String", "new", "this",
        "super", "null", "true", "false", "try", "catch", "finally", "throw", "throws", "in", "is", "as", "override",
        "open", "abstract", "data", "sealed", "enum", "suspend", "const", "lateinit", "by", "init", "typealias",
        "def", "lambda", "None", "True", "False", "self", "from", "with", "pass", "yield", "async", "await",
        "function", "let", "export", "default", "extends", "implements", "instanceof", "typeof", "delete", "switch",
        "case", "struct", "impl", "fn", "pub", "mut", "use", "mod", "trait", "where", "match", "type", "func", "go",
        "defer", "select", "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "CREATE", "TABLE", "echo", "fi", "then", "esac",
    )

    private val clike = Regex("""(/\*[\s\S]*?\*/|//[^\n]*)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|(\b[A-Za-z_][A-Za-z0-9_]*\b)""")
    private val hash = Regex("""(#[^\n]*)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|(\b[A-Za-z_][A-Za-z0-9_]*\b)""")
    private val markup = Regex("""(<!--[\s\S]*?-->)|(</?[A-Za-z][^>]*>)""")

    fun highlight(text: String, family: Family, c: SyntaxColors): AnnotatedString {
        if (family == Family.Plain || text.length > 250_000) return AnnotatedString(text)
        return buildAnnotatedString {
            append(text)
            when (family) {
                Family.Markup -> for (m in markup.findAll(text)) {
                    val style = if (m.groups[1] != null) SpanStyle(color = c.comment, fontStyle = FontStyle.Italic) else SpanStyle(color = c.tag)
                    addStyle(style, m.range.first, m.range.last + 1)
                }
                else -> for (m in (if (family == Family.Hash) hash else clike).findAll(text)) {
                    val g = m.groups
                    val style = when {
                        g[1] != null -> SpanStyle(color = c.comment, fontStyle = FontStyle.Italic)
                        g[2] != null -> SpanStyle(color = c.string)
                        g[3] != null -> SpanStyle(color = c.number)
                        m.value in keywords -> SpanStyle(color = c.keyword)
                        else -> null
                    }
                    if (style != null) addStyle(style, m.range.first, m.range.last + 1)
                }
            }
        }
    }
}
