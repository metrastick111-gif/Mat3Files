package com.mat3files

import android.os.Environment
import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.ui.graphics.vector.ImageVector
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class Kind { Folder, Image, Video, Audio, Doc, Code, Archive, Apk, Other }

data class FileItem(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val kind: Kind,
    val children: Int = 0,
)

data class Root(val nameRes: Int, val path: String)

sealed interface Screen {
    data class Folder(val path: String) : Screen
    data object Search : Screen
    data object Theme : Screen
    data object Plugins : Screen
    data object Terminal : Screen
    data object Categories : Screen
    data class ArchiveView(val path: String, val inner: String) : Screen
    data class SectionList(val section: Section) : Screen
    data class Editor(val path: String) : Screen
    data object Trash : Screen
    data object Analyze : Screen
}

/** Расширения файлов, которые открываются во встроенном редакторе. */
val CODE_EXT = setOf(
    "txt", "log", "md", "json", "xml", "html", "htm", "css", "js", "ts", "jsx", "tsx", "kt", "kts", "java",
    "py", "c", "h", "cpp", "hpp", "cs", "go", "rs", "swift", "dart", "php", "rb", "lua", "sh", "bat", "cmd",
    "ps1", "gradle", "properties", "yml", "yaml", "toml", "ini", "cfg", "conf", "csv", "tsv", "sql",
    "gitignore", "env", "svg", "vue", "smali", "srt", "vtt", "tex", "pro", "pl", "r", "lock",
)
private val EDITABLE_NAMES = setOf("Makefile", "Dockerfile", "LICENSE", "README", "CHANGELOG", "NOTICE")

fun isEditableName(name: String): Boolean =
    name.substringAfterLast('.', "").lowercase() in CODE_EXT || name in EDITABLE_NAMES

fun kindOf(name: String, isDir: Boolean): Kind {
    if (isDir) return Kind.Folder
    if (isEditableName(name)) return Kind.Code
    return when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif" -> Kind.Image
        "mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v" -> Kind.Video
        "mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr", "wma" -> Kind.Audio
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "rtf", "odt", "epub", "fb2" -> Kind.Doc
        "zip", "rar", "7z", "tar", "gz", "bz2", "xz" -> Kind.Archive
        "apk", "apks", "xapk" -> Kind.Apk
        else -> Kind.Other
    }
}

/** Умные разделы на главной: фильтры по индексу MediaStore. */
enum class Section(@StringRes val title: Int, val icon: ImageVector) {
    Recent(R.string.sec_recent, Icons.Rounded.Schedule),
    Screenshots(R.string.sec_screenshots, Icons.Rounded.PhoneAndroid),
    Downloads(R.string.sec_downloads, Icons.Rounded.Download),
    Large(R.string.sec_large, Icons.Rounded.Storage),
    Images(R.string.sec_images, Icons.Rounded.Image),
    Videos(R.string.sec_videos, Icons.Rounded.Movie),
    Audio(R.string.sec_audio, Icons.Rounded.MusicNote),
    Docs(R.string.sec_docs, Icons.Rounded.Description),
    Archives(R.string.sec_archives, Icons.Rounded.FolderZip),
    Apks(R.string.sec_apks, Icons.Rounded.Android);

    fun filter(items: List<FileItem>): List<FileItem> {
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath + "/"
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        return when (this) {
            Recent -> items.filter { it.modified >= weekAgo }.sortedByDescending { it.modified }.take(500)
            Screenshots -> items.filter {
                it.kind == Kind.Image &&
                    (it.path.contains("/Screenshots/", true) || it.name.startsWith("Screenshot", true))
            }.sortedByDescending { it.modified }
            Downloads -> items.filter { it.path.startsWith(downloads) }.sortedByDescending { it.modified }
            Large -> items.filter { it.size >= 100L * 1024 * 1024 }.sortedByDescending { it.size }
            Images -> items.filter { it.kind == Kind.Image }.sortedByDescending { it.modified }
            Videos -> items.filter { it.kind == Kind.Video }.sortedByDescending { it.modified }
            Audio -> items.filter { it.kind == Kind.Audio }.sortedByDescending { it.modified }
            Docs -> items.filter { it.kind == Kind.Doc || it.kind == Kind.Code }.sortedByDescending { it.modified }
            Archives -> items.filter { it.kind == Kind.Archive }.sortedByDescending { it.modified }
            Apks -> items.filter { it.kind == Kind.Apk }.sortedByDescending { it.modified }
        }
    }
}

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes Б"
    val units = arrayOf("КБ", "МБ", "ГБ", "ТБ")
    var value = bytes.toDouble()
    var i = -1
    while (value >= 1024 && i < units.lastIndex) {
        value /= 1024
        i++
    }
    return if (value >= 100 || i == 0) "%.0f %s".format(value, units[i]) else "%.1f %s".format(value, units[i])
}

fun formatDate(ms: Long): String {
    if (ms <= 0) return ""
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = ms }
    val pattern = if (now.get(Calendar.YEAR) == then.get(Calendar.YEAR)) "d MMM, HH:mm" else "d MMM yyyy"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ms))
}
