package com.mat3files

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material3.Button
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Switch
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.rememberCoroutineScope
import java.io.File

/** Сведения об APK, прочитанные из самого файла. */
data class ApkInfo(
    val label: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val installedVersionName: String?,
    val installedVersionCode: Long,
    val icon: ImageBitmap?,
    val size: Long,
)

/** Собственный установщик: сессия PackageInstaller или тихая установка через Shizuku/Root (`pm install`). */
object ApkInstaller {
    private const val ACTION = "com.mat3files.INSTALL_RESULT"
    private val main = Handler(Looper.getMainLooper())

    private fun toast(context: Context, text: String) = main.post { Toast.makeText(context, text, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    fun read(context: Context, path: String): ApkInfo? {
        val pm = context.packageManager
        val info = pm.getPackageArchiveInfo(path, 0) ?: return null
        val app = info.applicationInfo ?: return null
        app.sourceDir = path
        app.publicSourceDir = path
        val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        val installed = try {
            pm.getPackageInfo(info.packageName, 0)
        } catch (_: Exception) {
            null
        }
        val installedCode = installed?.let { if (Build.VERSION.SDK_INT >= 28) it.longVersionCode else it.versionCode.toLong() } ?: -1L
        val icon = try {
            pm.getApplicationIcon(app).toBitmap(128, 128).asImageBitmap()
        } catch (_: Exception) {
            null
        }
        return ApkInfo(
            label = pm.getApplicationLabel(app).toString(),
            packageName = info.packageName,
            versionName = info.versionName ?: "?",
            versionCode = code,
            installedVersionName = installed?.versionName,
            installedVersionCode = installedCode,
            icon = icon,
            size = File(path).length(),
        )
    }

    fun canInstall(context: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    /** Через систему: Android сам спросит подтверждение (без Shizuku/Root обойти это нельзя). Ход установки — в [onState]. */
    fun installSession(context: Context, path: String, onState: (InstallState) -> Unit) {
        val app = context.applicationContext
        try {
            val installer = app.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val file = File(path)
            params.setSize(file.length())
            // обновления приложений, установленных нами, система ставит без вопросов (Android 12+)
            if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            val id = installer.createSession(params)

            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, intent: Intent) {
                    when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
                        PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                            onState(InstallState.Confirm)
                            @Suppress("DEPRECATION")
                            val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                            if (confirm != null) c.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        PackageInstaller.STATUS_SUCCESS -> {
                            onState(InstallState.Done)
                            runCatching { c.unregisterReceiver(this) }
                        }
                        else -> {
                            val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE).orEmpty()
                            onState(InstallState.Failed(msg))
                            runCatching { c.unregisterReceiver(this) }
                        }
                    }
                }
            }
            ContextCompat.registerReceiver(app, receiver, IntentFilter(ACTION + id), ContextCompat.RECEIVER_NOT_EXPORTED)

            onState(InstallState.Working(0f))
            installer.openSession(id).use { session ->
                file.inputStream().use { input ->
                    session.openWrite("base.apk", 0, file.length()).use { out ->
                        val buf = ByteArray(256 * 1024)
                        var done = 0L
                        val total = file.length().coerceAtLeast(1L)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onState(InstallState.Working(done.toFloat() / total))
                        }
                        session.fsync(out)
                    }
                }
                val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
                val pi = android.app.PendingIntent.getBroadcast(app, id, Intent(ACTION + id).setPackage(app.packageName), flags)
                onState(InstallState.Working(1f))
                session.commit(pi.intentSender)
            }
        } catch (e: Exception) {
            onState(InstallState.Failed(e.message ?: ""))
        }
    }

    /** Установка прямо в приложении, без окна подтверждения: через Shizuku или Root (`pm install`). */
    fun installSilent(path: String, allowDowngrade: Boolean, onState: (InstallState) -> Unit) {
        onState(InstallState.Working(-1f))
        // системный pm не читает файлы из /storage/emulated/0 (fuse), поэтому ставим из /data/local/tmp
        val tmp = "/data/local/tmp/m3_install.apk"
        val cmd = "cp " + ShellFs.q(path) + " " + tmp + " && chmod 644 " + tmp +
            " && pm install -r " + (if (allowDowngrade) "-d " else "") + tmp + "; rc=\$?; rm -f " + tmp + "; exit \$rc"
        val r = Shell.exec(cmd, preferRoot = Shell.shizuku != ShizukuState.Connected && Shell.rootReady)
        if (r == null) {
            onState(InstallState.Failed(""))
            return
        }
        if (r.first == 0 && r.second.contains("Success", ignoreCase = true)) onState(InstallState.Done)
        else onState(InstallState.Failed(r.second.trim()))
    }

    /** Понятное объяснение частых ошибок установки. */
    fun explain(context: Context, raw: String): String {
        val hint = when {
            "UPDATE_INCOMPATIBLE" in raw || "SIGNATURES_DO_NOT_MATCH" in raw -> R.string.install_err_signature
            "VERSION_DOWNGRADE" in raw -> R.string.install_err_downgrade
            "INSUFFICIENT_STORAGE" in raw -> R.string.install_err_storage
            "OLDER_SDK" in raw || "NEWER_SDK" in raw -> R.string.install_err_sdk
            "NO_MATCHING_ABIS" in raw -> R.string.install_err_abi
            "PARSE_FAILED" in raw || "INVALID_APK" in raw -> R.string.install_err_parse
            else -> null
        }
        return (hint?.let { context.getString(it) + "\n" } ?: "") + raw.take(300)
    }
}

sealed interface InstallState {
    data object Idle : InstallState
    /** [progress] от 0 до 1; отрицательное — ход неизвестен. */
    data class Working(val progress: Float) : InstallState
    data object Confirm : InstallState
    data object Done : InstallState
    data class Failed(val message: String) : InstallState
}

@Composable
fun InstallApkDialog(vm: MainViewModel, d: DialogState.InstallApk) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val info by produceState<ApkInfo?>(null, d.path) {
        value = withContext(Dispatchers.IO) { ApkInstaller.read(context, d.path) }
    }
    var state by remember { mutableStateOf<InstallState>(InstallState.Idle) }
    var allowDowngrade by remember { mutableStateOf(false) }
    val name = File(d.path).name
    val busy = state is InstallState.Working || state is InstallState.Confirm
    val i = info
    val isDowngrade = i != null && i.installedVersionCode > i.versionCode

    Dialog(
        onDismissRequest = { if (state !is InstallState.Working) vm.dialog = null },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            shape = RoundedCornerShape(36.dp),
            color = cs.surfaceContainerHigh,
            modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
        ) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(84.dp).clip(RoundedCornerShape(28.dp)).background(cs.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    val bmp = i?.icon
                    if (bmp != null) Image(bmp, null, Modifier.size(64.dp))
                    else Icon(Icons.Rounded.Android, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(44.dp))
                }
                Spacer(Modifier.height(14.dp))
                if (i == null) {
                    Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.install_reading), color = cs.onSurfaceVariant)
                } else {
                    Text(i.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(i.packageName, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    val status = when {
                        i.installedVersionCode < 0 -> stringResource(R.string.install_new)
                        i.versionCode > i.installedVersionCode -> stringResource(R.string.install_update, i.installedVersionName ?: "?")
                        i.versionCode == i.installedVersionCode -> stringResource(R.string.install_same)
                        else -> stringResource(R.string.install_downgrade, i.installedVersionName ?: "?")
                    }
                    Box(
                        Modifier.clip(RoundedCornerShape(16.dp)).background(if (isDowngrade) cs.errorContainer else cs.secondaryContainer)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                    ) { Text(status, color = if (isDowngrade) cs.onErrorContainer else cs.onSecondaryContainer, style = MaterialTheme.typography.labelLarge) }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        stringResource(R.string.install_version, i.versionName, i.versionCode.toString()) + " · " + formatSize(i.size),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }

                // ход установки — прямо здесь
                val st = state
                if (st !is InstallState.Idle) {
                    Spacer(Modifier.height(16.dp))
                    when (st) {
                        is InstallState.Working -> {
                            if (st.progress >= 0f) LinearProgressIndicator(progress = { st.progress }, modifier = Modifier.fillMaxWidth())
                            else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(6.dp))
                            Text(stringResource(R.string.install_working), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        is InstallState.Confirm ->
                            Text(stringResource(R.string.install_confirm), color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                        is InstallState.Done ->
                            Text(stringResource(R.string.install_done), color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        is InstallState.Failed -> Text(
                            stringResource(R.string.install_failed) + "\n" + ApkInstaller.explain(context, st.message),
                            color = cs.error,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                        )
                        else -> Unit
                    }
                }

                if (isDowngrade && Shell.available && state !is InstallState.Done) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.install_allow_downgrade), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = allowDowngrade, onCheckedChange = { allowDowngrade = it })
                    }
                }

                Spacer(Modifier.height(20.dp))
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (state is InstallState.Done) {
                        val pkg = i?.packageName
                        val launch = pkg?.let { context.packageManager.getLaunchIntentForPackage(it) }
                        if (launch != null) {
                            Button(
                                onClick = {
                                    vm.dialog = null
                                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text(stringResource(R.string.install_open)) }
                        }
                    } else {
                        Button(
                            enabled = i != null && !busy,
                            onClick = {
                                if (Shell.available) {
                                    scope.launch(Dispatchers.IO) { ApkInstaller.installSilent(d.path, allowDowngrade) { state = it } }
                                } else if (!ApkInstaller.canInstall(context)) {
                                    ApkInstaller.openInstallPermission(context)
                                    Toast.makeText(context, R.string.install_need_permission, Toast.LENGTH_LONG).show()
                                } else {
                                    scope.launch(Dispatchers.IO) { ApkInstaller.installSession(context, d.path) { state = it } }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(if (Shell.available) R.string.install_button_inapp else R.string.install_button)) }
                        if (Archives.formatOf(name) != null) {
                            FilledTonalButton(
                                enabled = !busy,
                                onClick = {
                                    vm.dialog = null
                                    vm.push(Screen.ArchiveView(d.path, ""))
                                },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text(stringResource(R.string.install_contents)) }
                        }
                    }
                    TextButton(
                        enabled = state !is InstallState.Working,
                        onClick = { vm.dialog = null },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(if (state is InstallState.Done) R.string.act_close else R.string.cancel)) }
                }
            }
        }
    }
}
