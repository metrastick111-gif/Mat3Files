package com.mat3files

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.provider.OpenableColumns
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    /** APK, открытый из другого приложения (браузер, Telegram, «Открыть с помощью»): показываем наш установщик. */
    private fun handleIncoming(i: Intent?) {
        val uri = i?.data ?: return
        if (i.action != Intent.ACTION_VIEW && i.action != Intent.ACTION_INSTALL_PACKAGE) return
        lifecycleScope.launch {
            val path = withContext(Dispatchers.IO) { resolveIncomingApk(uri) }
            if (path != null) vm.dialog = DialogState.InstallApk(path)
        }
    }

    private fun resolveIncomingApk(uri: Uri): String? {
        if (uri.scheme == "file") return uri.path?.takeIf { File(it).isFile }
        if (uri.scheme != "content") return null
        return try {
            var name = "incoming.apk"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { name = it }
            }
            if (!name.endsWith(".apk", ignoreCase = true)) name += ".apk"
            // кладём туда, где файл увидят и мы, и shell (для установки через Shizuku/Root)
            val dir = File(Environment.getExternalStorageDirectory(), ".Mat3Stage").apply { mkdirs() }
            dir.listFiles()?.filter { it.name.startsWith("incoming_") }?.forEach { it.delete() }
            val out = File(dir, "incoming_" + name.replace('/', '_'))
            contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: return null
            out.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIncoming(intent)
        setContent {
            Mat3FilesTheme(vm.theme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Root(vm)
                }
            }
        }
    }
}

fun hasAllFilesAccess(context: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
    }

@Composable
private fun Root(vm: MainViewModel) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAllFilesAccess(context)) }
    // Пользователь возвращается из системных настроек — перепроверяем доступ и обновляем индекс
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasAllFilesAccess(context)
        if (granted) vm.reload()
    }
    if (!granted) {
        PermissionScreen { granted = hasAllFilesAccess(context) }
        return
    }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        for (message in vm.messages) snackbar.showSnackbar(message)
    }
    BackHandler(enabled = vm.canGoBack()) { vm.back() }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    CompositionLocalProvider(LocalOpenDrawer provides { scope.launch { drawerState.open() } }) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = { AppDrawer(vm) { scope.launch { drawerState.close() } } },
    ) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            AnimatedContent(
                targetState = vm.current,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    (fadeIn(tween(220)) + scaleIn(initialScale = 0.96f, animationSpec = tween(220))) togetherWith
                        fadeOut(tween(110))
                },
                label = "screen",
            ) { screen ->
                when (screen) {
                    is Screen.Folder -> FolderScreen(vm, screen.path)
                    Screen.Search -> SearchScreen(vm)
                    Screen.Theme -> ThemeScreen(vm)
                    Screen.Plugins -> PluginsScreen(vm)
                    Screen.Terminal -> TerminalScreen(vm)
                    Screen.Categories -> CategoriesScreen(vm)
                    is Screen.ArchiveView -> ArchiveViewScreen(vm, screen.path, screen.inner)
                    is Screen.SectionList -> SectionScreen(vm, screen.section)
                    is Screen.Editor -> EditorScreen(vm, screen.path)
                    Screen.Trash -> TrashScreen(vm)
                    Screen.Analyze -> AnalyzeScreen(vm)
                }
            }

            // уведомления сверху: не перекрывают кнопки и нижние панели
            StyledSnackbarHost(snackbar, remember { vm.errorMessages() }, Modifier.align(Alignment.TopCenter))

            Column(Modifier.align(Alignment.BottomCenter)) {
                AnimatedVisibility(vm.op != null, enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it }) {
                    OperationCard(vm)
                }
                AnimatedVisibility(
                    visible = vm.selected.isNotEmpty(),
                    enter = fadeIn() + slideInVertically { it },
                    exit = fadeOut() + slideOutVertically { it },
                ) { SelectionBar(vm) }
                val screen = vm.current
                AnimatedVisibility(
                    visible = vm.pending != null && vm.selected.isEmpty() && screen is Screen.Folder,
                    enter = fadeIn() + slideInVertically { it },
                    exit = fadeOut() + slideOutVertically { it },
                ) { PasteBar(vm, (screen as? Screen.Folder)?.path.orEmpty()) }
                AnimatedVisibility(
                    visible = vm.pending != null && vm.selected.isEmpty() && screen !is Screen.Folder && screen !is Screen.Editor,
                    enter = fadeIn() + slideInVertically { it },
                    exit = fadeOut() + slideOutVertically { it },
                ) { PasteHintBar(vm) }
            }
        }
    }
    }
    }
    FilterSheet(vm)
    Dialogs(vm)
    Viewer(vm)
}

// ───────────────────────── Доступ к файлам ─────────────────────────

@Composable
private fun PermissionScreen(onChecked: () -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { onChecked() }
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(cs.primaryContainer),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Folder, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(48.dp)) }
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.perm_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.perm_text), color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + context.packageName)),
                )
            } else {
                launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
        }) { Text(stringResource(R.string.perm_button)) }
    }
}

// ───────────────────────── Нижние панели ─────────────────────────

@Composable
private fun SelectionBar(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val all = vm.selected.toList()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(30.dp))
            .background(cs.surfaceContainerHigh)
            .padding(horizontal = 4.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        BarAction(Icons.Rounded.ContentCopy, stringResource(R.string.act_copy), cs.primaryContainer, cs.onPrimaryContainer, Modifier.weight(1f)) {
            vm.startCopy(move = false)
        }
        BarAction(Icons.Rounded.ContentCut, stringResource(R.string.act_move), cs.secondaryContainer, cs.onSecondaryContainer, Modifier.weight(1f)) {
            vm.startCopy(move = true)
        }
        BarAction(Icons.Rounded.Delete, stringResource(R.string.act_delete), cs.errorContainer, cs.onErrorContainer, Modifier.weight(1f)) {
            vm.dialog = DialogState.Delete(all)
        }
        BarAction(Icons.Rounded.Share, stringResource(R.string.act_share), cs.tertiaryContainer, cs.onTertiaryContainer, Modifier.weight(1f)) {
            shareFiles(context, all)
        }
    }
}

/** Цветная кнопка нижней панели: подпись не обрезается (мелкий шрифт и многоточие). */
@Composable
private fun BarAction(icon: ImageVector, label: String, container: Color, content: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.pressable(onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(width = 52.dp, height = 34.dp).clip(RoundedCornerShape(17.dp)).background(container),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, label, tint = content, modifier = Modifier.size(21.dp)) }
        Text(
            label,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun PasteBar(vm: MainViewModel, destination: String) {
    val cs = MaterialTheme.colorScheme
    val p = vm.pending ?: return
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(cs.primaryContainer)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            stringResource(if (p.move) R.string.paste_move else R.string.paste_copy, p.paths.size),
            color = cs.onPrimaryContainer,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = vm::cancelPending) { Text(stringResource(R.string.cancel)) }
        Button(onClick = { vm.paste(destination) }) { Text(stringResource(R.string.paste_here)) }
    }
}

@Composable
private fun OperationCard(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val op = vm.op ?: return
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(cs.secondaryContainer)
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(op.titleRes),
                color = cs.onSecondaryContainer,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = vm::cancelOp) { Text(stringResource(R.string.cancel)) }
        }
        Spacer(Modifier.height(6.dp))
        if (op.total > 0) {
            LinearProgressIndicator(progress = { (op.done.toFloat() / op.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        } else {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
    }
}

/** Подсказка, когда файлы скопированы, а открыт не проводник (главная, раздел, корзина…). */
@Composable
private fun PasteHintBar(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val p = vm.pending ?: return
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(cs.primaryContainer)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            stringResource(R.string.paste_hint),
            color = cs.onPrimaryContainer,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = vm::cancelPending) { Text(stringResource(R.string.cancel)) }
        Button(onClick = {
            vm.dialog = DialogState.PickFolder(if (p.move) PickMode.Move else PickMode.Copy, p.paths)
        }) { Text(stringResource(R.string.paste_choose)) }
    }
}
