package com.mat3files

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("mat3files", Context.MODE_PRIVATE)

    var grid: Boolean
        get() = sp.getBoolean("grid", false)
        set(v) { sp.edit().putBoolean("grid", v).apply() }

    /** 0 — имя, 1 — дата, 2 — размер, 3 — тип. */
    var sortBy: Int
        get() = sp.getInt("sort_by", 0)
        set(v) { sp.edit().putInt("sort_by", v).apply() }

    var sortDesc: Boolean
        get() = sp.getBoolean("sort_desc", false)
        set(v) { sp.edit().putBoolean("sort_desc", v).apply() }

    var showHidden: Boolean
        get() = sp.getBoolean("show_hidden", false)
        set(v) { sp.edit().putBoolean("show_hidden", v).apply() }

    /** Папки, закреплённые в быстром доступе. */
    var favorites: Set<String>
        get() = sp.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("favorites", v).apply() }

    // ── тема ──
    /** 0 — как в системе, 1 — светлая, 2 — тёмная. */
    var themeMode: Int
        get() = sp.getInt("theme_mode", 0)
        set(v) { sp.edit().putInt("theme_mode", v).apply() }

    var amoled: Boolean
        get() = sp.getBoolean("amoled", false)
        set(v) { sp.edit().putBoolean("amoled", v).apply() }

    /** 0 — системные цвета (Material You), 1 — готовые акценты, 2 — свой цвет. */
    var colorSource: Int
        get() = sp.getInt("color_source", 0)
        set(v) { sp.edit().putInt("color_source", v).apply() }

    var preset: Int
        get() = sp.getInt("preset", 0)
        set(v) { sp.edit().putInt("preset", v).apply() }

    var customHue: Float
        get() = sp.getFloat("custom_hue", 265f)
        set(v) { sp.edit().putFloat("custom_hue", v).apply() }

    var customSat: Float
        get() = sp.getFloat("custom_sat", 1f)
        set(v) { sp.edit().putFloat("custom_sat", v).apply() }

    // ── вид списка ──
    /** 0 — компактно, 1 — обычно, 2 — просторно. */
    var density: Int
        get() = sp.getInt("density", 1)
        set(v) { sp.edit().putInt("density", v).apply() }

    var foldersFirst: Boolean
        get() = sp.getBoolean("folders_first", true)
        set(v) { sp.edit().putBoolean("folders_first", v).apply() }

    // ── расширенный доступ ──
    var rootEnabled: Boolean
        get() = sp.getBoolean("root_enabled", false)
        set(v) { sp.edit().putBoolean("root_enabled", v).apply() }

    /** Закреплённые файлы и папки. */
    var pinned: Set<String>
        get() = sp.getStringSet("pinned", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("pinned", v).apply() }

    /** Порядок разделов (имена через запятую). */
    var sectionOrder: String
        get() = sp.getString("section_order", "") ?: ""
        set(v) { sp.edit().putString("section_order", v).apply() }
}
