package com.mat3files

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TrashEntry(
    val id: String,
    val name: String,
    val original: String,
    val stored: String,
    val time: Long,
    val size: Long,
    val isDir: Boolean,
)

/** Корзина: удалённые файлы переезжают в скрытую папку .Mat3Trash на том же диске и живут там 30 дней. */
class TrashStore(context: Context) {
    private val file = File(context.filesDir, "trash.json")
    val entries = mutableStateListOf<TrashEntry>()

    init {
        load()
    }

    private fun load() {
        try {
            if (!file.exists()) return
            val arr = JSONArray(file.readText())
            val list = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TrashEntry(
                    o.getString("id"), o.getString("name"), o.getString("original"), o.getString("stored"),
                    o.getLong("time"), o.getLong("size"), o.optBoolean("dir"),
                )
            }
            entries.clear()
            entries.addAll(list.sortedByDescending { it.time })
        } catch (_: Exception) {
            entries.clear()
        }
    }

    private fun save() {
        val arr = JSONArray()
        entries.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("original", it.original)
                    .put("stored", it.stored).put("time", it.time).put("size", it.size).put("dir", it.isDir),
            )
        }
        try {
            file.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    fun add(entry: TrashEntry) {
        entries.add(0, entry)
        save()
    }

    fun remove(id: String) {
        entries.removeAll { it.id == id }
        save()
    }

    fun clear() {
        entries.clear()
        save()
    }

    /** Записи старше [days] дней — их нужно удалить с диска. */
    fun expired(days: Int = 30): List<TrashEntry> {
        val limit = System.currentTimeMillis() - days * 24L * 3600 * 1000
        return entries.filter { it.time < limit }
    }
}
