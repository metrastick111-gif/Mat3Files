package com.mat3files

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.rounded.FolderSpecial
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.zIndex
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.SdCard
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

// ───────────────────────── Боковая панель ─────────────────────────

/** Значок Telegram (бумажный самолётик). */
private fun telegramIcon(): ImageVector =
    ImageVector.Builder("telegram", 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = PathParser().parsePathString(
            "M9.78 18.65L10.06 14.42L17.74 7.5C18.08 7.19 17.67 7.04 17.22 7.31L7.74 13.3L3.64 12C2.76 11.75 2.75 11.14 3.84 10.7" +
                "L19.81 4.54C20.54 4.21 21.24 4.72 20.96 5.84L18.24 18.65C18.05 19.56 17.5 19.78 16.74 19.36L12.6 16.3L10.61 18.23" +
                "C10.38 18.46 10.19 18.65 9.78 18.65Z",
        ).toNodes(),
        fill = SolidColor(Color.White),
    ).build()

@Composable
fun AppDrawer(vm: MainViewModel, close: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    ModalDrawerSheet(drawerContainerColor = cs.surfaceContainerLow) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 16.dp)) {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 12.dp, bottom = 12.dp),
            )

            // 1. Память: сколько занято
            StorageCard(vm) {
                close()
                vm.openRoot(vm.rootPath)
            }
            Spacer(Modifier.height(8.dp))
            // Корневой каталог: смотреть можно всегда, менять и запускать — с Root
            RootStorageCard(vm) {
                close()
                vm.openRoot("/")
            }
            if (vm.roots.size > 1) {
                vm.roots.drop(1).forEach { root ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(root.nameRes)) },
                        icon = { Icon(Icons.Rounded.SdCard, null) },
                        selected = false,
                        onClick = {
                            close()
                            vm.openRoot(root.path)
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            // 2. Тема и настройки
            DrawerItem(Icons.Rounded.Palette, stringResource(R.string.drawer_theme)) {
                close()
                vm.push(Screen.Theme)
            }
            // 3. Корзина
            DrawerItem(Icons.Rounded.Delete, stringResource(R.string.home_trash), badge = vm.trash.entries.size.takeIf { it > 0 }?.toString()) {
                close()
                vm.push(Screen.Trash)
            }
            // 4. Плагины (пока недоступны)
            DrawerItem(Icons.Rounded.Extension, stringResource(R.string.drawer_plugins), badge = stringResource(R.string.badge_soon)) {
                close()
                vm.push(Screen.Plugins)
            }
            // 5. Терминал
            DrawerItem(Icons.Rounded.Terminal, stringResource(R.string.drawer_terminal)) {
                close()
                val folder = vm.stack.lastOrNull { it is Screen.Folder } as? Screen.Folder
                vm.openTerminal(folder?.path ?: vm.rootPath)
            }

            HorizontalDivider(Modifier.padding(vertical = 10.dp, horizontal = 12.dp))

            DrawerItem(Icons.Rounded.Category, stringResource(R.string.drawer_categories)) {
                close()
                vm.push(Screen.Categories)
            }
            DrawerItem(Icons.Rounded.PieChart, stringResource(R.string.home_analyze)) {
                close()
                vm.push(Screen.Analyze)
            }
        }

        // самый низ: наш Telegram
        val icon = remember { telegramIcon() }
        Row(
            Modifier
                .padding(12.dp)
                .fillMaxWidth()
                .pressable(onClick = {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Update.TELEGRAM_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                })
                .clip(RoundedCornerShape(26.dp))
                .background(cs.secondaryContainer)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF229ED9)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.tg_title), fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer)
                Text(stringResource(R.string.tg_subtitle), style = MaterialTheme.typography.bodySmall, color = cs.onSecondaryContainer.copy(alpha = 0.75f))
            }
        }
    }
}

@Composable
private fun DrawerItem(icon: ImageVector, label: String, badge: String? = null, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label) },
        icon = { Icon(icon, null) },
        badge = { if (badge != null) Text(badge, style = MaterialTheme.typography.labelMedium) },
        selected = false,
        onClick = onClick,
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
    )
}

/** Карточка внутренней памяти. */
@Composable
fun StorageCard(vm: MainViewModel, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    UsageCard(
        title = stringResource(R.string.storage_title),
        total = vm.storageTotal,
        free = vm.storageFree,
        container = cs.primaryContainer,
        content = cs.onPrimaryContainer,
        arc = cs.primary,
        onClick = onClick,
    )
}

/** Карточка корневого каталога «/»: такая же, как у внутренней памяти, но другого цвета. */
@Composable
fun RootStorageCard(vm: MainViewModel, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    UsageCard(
        title = stringResource(R.string.drawer_root) + "  /",
        total = vm.rootTotal,
        free = vm.rootFree,
        container = cs.tertiaryContainer,
        content = cs.onTertiaryContainer,
        arc = cs.tertiary,
        onClick = onClick,
    )
}

/** Кольцо с процентом заполнения плавно «дорисовывается». */
@Composable
private fun UsageCard(
    title: String,
    total: Long,
    free: Long,
    container: Color,
    content: Color,
    arc: Color,
    onClick: () -> Unit,
) {
    val used = (total - free).coerceAtLeast(0)
    val fraction = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    val sweep = remember { Animatable(0f) }
    LaunchedEffect(fraction) { sweep.animateTo(fraction, tween(900)) }
    val track = content.copy(alpha = 0.15f)

    Row(
        Modifier
            .fillMaxWidth()
            .pressable(onClick)
            .clip(RoundedCornerShape(28.dp))
            .background(container)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(84.dp)) {
                val stroke = 10.dp.toPx()
                val inset = stroke / 2
                val arcSize = Size(size.width - stroke, size.height - stroke)
                drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                drawArc(arc, -90f, 360f * sweep.value, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            Text(
                "${(sweep.value * 100).toInt()}%",
                color = content,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            )
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium, color = content)
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.storage_used, formatSize(used), formatSize(total)),
                color = content.copy(alpha = 0.8f),
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                stringResource(R.string.storage_free, formatSize(free)),
                color = content.copy(alpha = 0.8f),
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

// ───────────────────────── Разделы ─────────────────────────

@Composable
fun CategoriesScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.drawer_categories), null, vm::back)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            QuickAccess(vm)
            Spacer(Modifier.height(10.dp))
            Text(
                stringResource(R.string.categories_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 4.dp, bottom = 10.dp),
            )
            SectionGrid(vm)
        }
    }
}

/** Сетка разделов: удержание карточки и перетаскивание меняют порядок. */
@Composable
private fun SectionGrid(vm: MainViewModel) {
    val haptic = LocalHapticFeedback.current
    val order by rememberUpdatedState(vm.sectionOrder)
    val bounds = remember { mutableStateMapOf<Section, Rect>() }
    var dragging by remember { mutableStateOf<Section?>(null) }
    var drag by remember { mutableStateOf(Offset.Zero) }
    var hover by remember { mutableStateOf<Section?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        vm.sectionOrder.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { section ->
                    val list = vm.sections[section].orEmpty()
                    val isDrag = dragging == section
                    val isHover = hover == section
                    val scale by animateFloatAsState(
                        if (isDrag) 1.07f else if (isHover) 0.93f else 1f,
                        spring(dampingRatio = 0.6f, stiffness = 500f), label = "sectionDrag",
                    )
                    Box(
                        Modifier
                            .weight(1f)
                            .onGloballyPositioned { bounds[section] = it.boundsInRoot() }
                            .zIndex(if (isDrag) 1f else 0f)
                            .graphicsLayer {
                                scaleX = scale
                                scaleY = scale
                                if (isDrag) {
                                    translationX = drag.x
                                    translationY = drag.y
                                }
                                alpha = if (isDrag) 0.93f else 1f
                            }
                            .pointerInput(section) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = {
                                        dragging = section
                                        drag = Offset.Zero
                                        hover = null
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        drag += amount
                                        val center = (bounds[section]?.center ?: Offset.Zero) + drag
                                        hover = order.firstOrNull { it != section && bounds[it]?.contains(center) == true }
                                    },
                                    onDragEnd = {
                                        hover?.let { vm.moveSection(section, it) }
                                        dragging = null
                                        hover = null
                                        drag = Offset.Zero
                                    },
                                    onDragCancel = {
                                        dragging = null
                                        hover = null
                                        drag = Offset.Zero
                                    },
                                )
                            },
                    ) {
                        SectionCard(section, list.size, list.sumOf { it.size }, vm.sectionOrder.indexOf(section)) {
                            vm.push(Screen.SectionList(section))
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun QuickAccess(vm: MainViewModel) {
    val folders = remember(vm.roots) {
        val base = File(vm.rootPath)
        listOf("Download", "DCIM", "Pictures", "Movies", "Music", "Documents")
            .map { it to File(base, it) }
            .filter { it.second.isDirectory }
            .map { it.first to it.second.absolutePath }
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 2.dp)) {
        items(vm.favorites.toList().filter { File(it).isDirectory }) { path ->
            AssistChip(
                onClick = { vm.push(Screen.Folder(path)) },
                label = { Text(File(path).name) },
                leadingIcon = { Icon(Icons.Rounded.Star, null, Modifier.size(AssistChipDefaults.IconSize)) },
            )
        }
        items(folders) { (name, path) ->
            AssistChip(
                onClick = { vm.push(Screen.Folder(path)) },
                label = { Text(name) },
                leadingIcon = { Icon(Icons.Rounded.Folder, null, Modifier.size(AssistChipDefaults.IconSize)) },
            )
        }
    }
}

@Composable
private fun SectionCard(section: Section, count: Int, size: Long, colorIndex: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val palette = listOf(
        cs.primaryContainer to cs.onPrimaryContainer,
        cs.secondaryContainer to cs.onSecondaryContainer,
        cs.tertiaryContainer to cs.onTertiaryContainer,
        cs.surfaceContainerHighest to cs.onSurface,
    )
    val (bg, fg) = palette[colorIndex % palette.size]
    Column(
        Modifier
            .fillMaxWidth()
            .height(112.dp)
            .pressable(onClick)
            .clip(RoundedCornerShape(26.dp))
            .background(bg)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Icon(section.icon, null, tint = fg, modifier = Modifier.size(28.dp))
        Column {
            Text(stringResource(section.title), color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                stringResource(R.string.section_stats, count, formatSize(size)),
                color = fg.copy(alpha = 0.75f),
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

// ───────────────────────── Плагины (скоро) ─────────────────────────

@Composable
fun PluginsScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.plugins_title), null, vm::back)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(cs.tertiaryContainer),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Extension, null, tint = cs.onTertiaryContainer, modifier = Modifier.size(48.dp)) }
            Text(
                stringResource(R.string.plugins_soon_title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            Text(
                stringResource(R.string.plugins_soon_text),
                color = cs.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge,
            )
            listOf(R.string.plugins_idea1, R.string.plugins_idea2, R.string.plugins_idea3).forEach { res ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(cs.surfaceContainerHigh)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Extension, null, tint = cs.primary)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(res))
                }
            }
        }
    }
}
