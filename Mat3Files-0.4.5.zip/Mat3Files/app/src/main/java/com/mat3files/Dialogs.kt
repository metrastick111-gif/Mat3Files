package com.mat3files

import androidx.compose.foundation.background
import androidx.compose.material.icons.rounded.Android
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Link
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Dialogs(vm: MainViewModel) {
    when (val d = vm.dialog) {
        null -> Unit
        is DialogState.Actions -> ActionsDialog(vm, d)
        is DialogState.MultiActions -> MultiActionsDialog(vm, d)
        is DialogState.InstallApk -> InstallApkDialog(vm, d)
        is DialogState.Delete -> DeleteDialog(vm, d)
        is DialogState.Rename -> NameDialog(
            title = stringResource(R.string.rename_title),
            label = stringResource(R.string.new_name),
            icon = Icons.Rounded.DriveFileRenameOutline,
            initial = File(d.path).name,
            confirm = stringResource(R.string.ok),
            onDismiss = { vm.dialog = null },
            onConfirm = {
                vm.dialog = null
                vm.rename(d.path, it)
            },
        )
        is DialogState.NewFolder -> NameDialog(
            title = stringResource(R.string.new_folder),
            label = stringResource(R.string.folder_name),
            icon = Icons.Rounded.CreateNewFolder,
            initial = "",
            confirm = stringResource(R.string.create),
            onDismiss = { vm.dialog = null },
            onConfirm = {
                vm.dialog = null
                vm.createFolder(d.parent, it)
            },
        )
        is DialogState.NewFile -> NameDialog(
            title = stringResource(R.string.new_file),
            label = stringResource(R.string.file_name),
            icon = Icons.Rounded.NoteAdd,
            initial = "",
            confirm = stringResource(R.string.create),
            onDismiss = { vm.dialog = null },
            onConfirm = {
                vm.dialog = null
                vm.createFile(d.parent, it)
            },
        )
        is DialogState.Details -> DetailsDialog(d.path) { vm.dialog = null }
        is DialogState.Compress -> CompressDialog(vm, d)
        is DialogState.ArchiveInfo -> ArchiveDialog(vm, d)
        is DialogState.PickFolder -> PickFolderDialog(vm, d)
        DialogState.RootInfo -> RootInfoDialog { vm.dialog = null }

        is DialogState.Unsaved -> StyledDialog(
            title = stringResource(R.string.unsaved_title),
            icon = Icons.Rounded.Save,
            onDismiss = { vm.dialog = null },
            actions = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WideButton(stringResource(R.string.unsaved_save), {
                        vm.dialog = null
                        vm.saveEditor(d.path) { vm.closeEditor(d.path) }
                    })
                    WideButton(stringResource(R.string.unsaved_discard), {
                        vm.dialog = null
                        vm.closeEditor(d.path)
                    }, danger = true)
                    WideButton(stringResource(R.string.cancel), { vm.dialog = null }, tonal = true)
                }
            },
        ) { Text(File(d.path).name, color = MaterialTheme.colorScheme.onSurfaceVariant) }

        DialogState.EmptyTrash -> StyledDialog(
            title = stringResource(R.string.trash_empty_confirm_title),
            icon = Icons.Rounded.DeleteForever,
            danger = true,
            confirmText = stringResource(R.string.trash_empty_action),
            onConfirm = {
                vm.dialog = null
                vm.emptyTrash()
            },
            onDismiss = { vm.dialog = null },
        ) { Text(stringResource(R.string.trash_empty_confirm_text), color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

// ───────── простые окна ─────────

@Composable
private fun NameDialog(
    title: String,
    label: String,
    icon: ImageVector,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    StyledDialog(
        title = title,
        icon = icon,
        onDismiss = onDismiss,
        confirmText = confirm,
        confirmEnabled = text.isNotBlank(),
        onConfirm = { onConfirm(text) },
    ) { DialogField(text, { text = it }, label) }
}

@Composable
private fun DeleteDialog(vm: MainViewModel, d: DialogState.Delete) {
    StyledDialog(
        title = stringResource(R.string.delete_title),
        icon = Icons.Rounded.Delete,
        danger = true,
        onDismiss = { vm.dialog = null },
        actions = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                WideButton(stringResource(R.string.delete_trash), {
                    vm.dialog = null
                    vm.delete(d.paths, permanent = false)
                })
                WideButton(stringResource(R.string.delete_forever), {
                    vm.dialog = null
                    vm.delete(d.paths, permanent = true)
                }, danger = true)
                WideButton(stringResource(R.string.cancel), { vm.dialog = null }, tonal = true)
            }
        },
    ) { Text(stringResource(R.string.delete_text, d.paths.size), color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

// ───────── сжатие ─────────

@Composable
private fun CompressDialog(vm: MainViewModel, d: DialogState.Compress) {
    val defaultName = if (d.paths.size == 1) {
        File(d.paths[0]).let { if (it.isDirectory) it.name else it.nameWithoutExtension }
    } else {
        stringResource(R.string.archive_default_name)
    }
    var name by remember { mutableStateOf(defaultName) }
    var format by remember { mutableStateOf(ArchiveFormat.Zip) }
    StyledDialog(
        title = stringResource(R.string.compress_title),
        icon = Icons.Rounded.FolderZip,
        onDismiss = { vm.dialog = null },
        confirmText = stringResource(R.string.create),
        confirmEnabled = name.isNotBlank(),
        onConfirm = {
            vm.dialog = null
            vm.compress(d.paths, format, name)
        },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ArchiveFormat.entries.filter { it.canCreate }.forEach { f ->
                    FilterChip(selected = format == f, onClick = { format = f }, label = { Text(f.label) })
                }
            }
            DialogField(name, { name = it }, stringResource(R.string.archive_name), suffix = format.ext)
        }
    }
}

// ───────── содержимое архива ─────────

@Composable
private fun ArchiveDialog(vm: MainViewModel, d: DialogState.ArchiveInfo) {
    val file = File(d.path)
    val result by produceState<Result<Pair<List<Archives.Entry>, Long>>?>(null, d.path) {
        value = withContext(Dispatchers.IO) { runCatching { Archives.list(file) } }
    }
    val cs = MaterialTheme.colorScheme
    StyledDialog(
        title = file.name,
        icon = Icons.Rounded.FolderZip,
        onDismiss = { vm.dialog = null },
        dismissText = stringResource(R.string.act_close),
        confirmText = stringResource(R.string.archive_extract_here),
        confirmEnabled = result?.isSuccess == true,
        onConfirm = {
            vm.dialog = null
            vm.extract(d.path, file.parent.orEmpty(), subfolder = true)
        },
    ) {
        val r = result
        when {
            r == null -> Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            r.isFailure -> Text(stringResource(R.string.archive_error), color = cs.error)
            else -> {
                val (entries, total) = r.getOrThrow()
                Column {
                    Text(
                        stringResource(R.string.archive_summary, entries.size, formatSize(total)),
                        color = cs.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.height(220.dp).clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainerHighest)) {
                        items(entries) { e ->
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (e.isDir) Icons.Rounded.Folder else kindIcon(kindOf(e.name, false)),
                                    null, tint = cs.primary, modifier = Modifier.size(18.dp),
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                if (!e.isDir && e.size >= 0) Text(formatSize(e.size), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────── выбор папки ─────────

@Composable
private fun PickFolderDialog(vm: MainViewModel, d: DialogState.PickFolder) {
    val cs = MaterialTheme.colorScheme
    val startPath = d.paths.firstOrNull()?.let { File(it).parent } ?: vm.roots.firstOrNull()?.path.orEmpty()
    var cur by remember { mutableStateOf(startPath) }
    val rootPath = vm.roots.firstOrNull { cur == it.path || cur.startsWith(it.path + "/") }?.path
    val dirs = remember(cur, vm.showHidden) {
        File(cur).listFiles()
            ?.filter { it.isDirectory && (vm.showHidden || !it.name.startsWith(".")) }
            ?.sortedBy { it.name.lowercase() }
            .orEmpty()
    }
    val title = when (d.mode) {
        PickMode.Copy -> R.string.pick_copy
        PickMode.Move -> R.string.pick_move
        PickMode.Extract -> R.string.pick_extract
    }
    StyledDialog(
        title = stringResource(title),
        icon = Icons.Rounded.Folder,
        onDismiss = { vm.dialog = null },
        confirmText = stringResource(R.string.pick_here),
        onConfirm = {
            vm.dialog = null
            when (d.mode) {
                PickMode.Copy -> vm.pasteInto(d.paths, false, cur)
                PickMode.Move -> vm.pasteInto(d.paths, true, cur)
                PickMode.Extract -> vm.extract(d.paths[0], cur, subfolder = true)
            }
        },
    ) {
        Column {
            Text(cur, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.height(260.dp).clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerHighest)) {
                if (cur != rootPath) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().clickable { File(cur).parent?.let { cur = it } }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            IconBlob(Icons.Rounded.ArrowUpward, cs.tertiaryContainer, cs.onTertiaryContainer, 36.dp, 12.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(stringResource(R.string.pick_up), color = cs.primary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                items(dirs, key = { it.path }) { dir ->
                    Row(
                        Modifier.fillMaxWidth().clickable { cur = dir.absolutePath }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconBlob(Icons.Rounded.Folder, cs.primaryContainer, cs.onPrimaryContainer, 36.dp, 12.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(dir.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

// ───────── свойства ─────────

@Composable
private fun DetailsDialog(path: String, onDismiss: () -> Unit) {
    val file = File(path)
    val cs = MaterialTheme.colorScheme
    // размер папки считаем в фоне: он может быть большим
    val size by produceState(if (file.isDirectory) -1L else file.length(), path) {
        if (file.isDirectory) value = withContext(Dispatchers.IO) { FileOps.totalSize(file) }
    }
    StyledDialog(
        title = stringResource(R.string.details_title),
        icon = Icons.Rounded.Info,
        onDismiss = onDismiss,
        dismissText = null,
        confirmText = stringResource(R.string.ok),
        onConfirm = onDismiss,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DetailRow(stringResource(R.string.d_name), file.name, 0)
            DetailRow(stringResource(R.string.d_path), file.parent.orEmpty(), 1)
            DetailRow(stringResource(R.string.d_size), if (size < 0) "…" else formatSize(size), 2)
            DetailRow(stringResource(R.string.d_date), formatDate(file.lastModified()), 3)
            if (file.isDirectory) {
                DetailRow(stringResource(R.string.d_items), stringResource(R.string.folder_items, file.list()?.size ?: 0), 0)
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String, colorIndex: Int) {
    val (bg, fg) = blobColors(colorIndex)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(bg.copy(alpha = 0.55f)).padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = fg.copy(alpha = 0.75f))
        Text(value, fontWeight = FontWeight.SemiBold, color = fg)
    }
}

// ───────── плашка Root ─────────

@Composable
private fun RootInfoDialog(onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val info by produceState<Shell.RootInfoData?>(null) { value = Shell.collectInfo() }
    val on = Shell.rootEnabled
    StyledDialog(
        title = stringResource(R.string.root_title),
        icon = Icons.Rounded.AdminPanelSettings,
        onDismiss = onDismiss,
        dismissText = null,
        confirmText = stringResource(R.string.ok),
        onConfirm = onDismiss,
    ) {
        val i = info
        if (i == null) {
            Box(Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // состояние root: «Root: enable»
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (on && Shell.rootWorks) cs.primaryContainer else cs.errorContainer.copy(alpha = 0.6f))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "Root: " + stringResource(if (on) R.string.root_state_enable else R.string.root_state_disable),
                        fontWeight = FontWeight.Bold,
                        color = if (on && Shell.rootWorks) cs.onPrimaryContainer else cs.onErrorContainer,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        stringResource(if (Shell.rootWorks) R.string.root_access_yes else R.string.root_access_no),
                        color = if (on && Shell.rootWorks) cs.onPrimaryContainer else cs.onErrorContainer,
                    )
                }
                DetailRow(stringResource(R.string.info_model), i.model, 1)
                DetailRow(stringResource(R.string.info_android), i.android, 2)
                DetailRow(stringResource(R.string.info_kernel), i.kernel, 0)
                DetailRow(stringResource(R.string.info_su), i.suPath ?: stringResource(R.string.info_su_none), 3)
                if (i.selinux.isNotBlank()) DetailRow("SELinux", i.selinux, 1)
                if (!i.rootId.isNullOrBlank()) DetailRow("id", i.rootId, 2)
            }
        }
    }
}

// ───────── мини-окно действий (удержание файла) ─────────

@Composable
private fun ActionsDialog(vm: MainViewModel, d: DialogState.Actions) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val file = File(d.path)
    val shell = ShellFs.needsShell(d.path)
    val isDir = file.isDirectory
    val item = FileItem(
        d.path, file.name, isDir, if (isDir) 0L else file.length(), file.lastModified(), kindOf(file.name, isDir),
        if (isDir) (file.list()?.size ?: 0) else 0,
    )
    val pinned = d.path in vm.pinned
    fun close(block: () -> Unit) {
        vm.dialog = null
        block()
    }
    Dialog(onDismissRequest = { vm.dialog = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(36.dp),
            color = cs.surfaceContainerHigh,
            modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
        ) {
            Column(Modifier.padding(vertical = 16.dp).heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
                Row(Modifier.padding(horizontal = 22.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FileThumb(item, 52.dp, corner = 18.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        MiddleEllipsisText(file.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (isDir) stringResource(R.string.folder_items, item.children) else formatSize(item.size),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp, horizontal = 22.dp))
                ActionRow(Icons.Rounded.ContentCopy, R.string.act_copy, 0) { close { vm.startCopyOf(listOf(d.path), false) } }
                ActionRow(Icons.Rounded.ContentCut, R.string.act_move, 1) { close { vm.startCopyOf(listOf(d.path), true) } }
                ActionRow(Icons.Rounded.PushPin, if (pinned) R.string.act_unpin else R.string.act_pin, 2) { close { vm.togglePin(d.path) } }
                ActionRow(Icons.Rounded.DriveFileRenameOutline, R.string.act_rename, 3) { close { vm.dialog = DialogState.Rename(d.path) } }
                if (!shell) {
                    ActionRow(Icons.Rounded.FolderZip, R.string.act_compress, 0) { close { vm.dialog = DialogState.Compress(listOf(d.path)) } }
                    ActionRow(Icons.Rounded.Info, R.string.act_details, 1) { close { vm.dialog = DialogState.Details(d.path) } }
                    if (file.isFile) ActionRow(Icons.Rounded.Share, R.string.act_share, 2) { close { shareFiles(context, listOf(d.path)) } }
                    if (Archives.formatOf(file.name) != null) {
                        ActionRow(Icons.Rounded.Unarchive, R.string.act_extract_here, 3) {
                            close { vm.extract(d.path, file.parent.orEmpty(), subfolder = true) }
                        }
                    }
                }
                if (file.name.endsWith(".apk", ignoreCase = true)) {
                    ActionRow(Icons.Rounded.Android, R.string.install_button, 2) { close { vm.dialog = DialogState.InstallApk(d.path) } }
                }
                if (file.name.endsWith(".sh", ignoreCase = true)) {
                    ActionRow(Icons.Rounded.Terminal, R.string.act_run_terminal, 0) { close { vm.runInTerminal(d.path, 0) } }
                    if (Shell.available) ActionRow(Icons.Rounded.Terminal, R.string.act_run_shizuku, 1) { close { vm.runInTerminal(d.path, 1) } }
                    if (Shell.rootReady) ActionRow(Icons.Rounded.Terminal, R.string.act_run_root, 2) { close { vm.runInTerminal(d.path, 2) } }
                }
                if (!shell && Archives.formatOf(file.name) != null) {
                    ActionRow(Icons.Rounded.Unarchive, R.string.act_extract_to, 4) {
                        close { vm.dialog = DialogState.PickFolder(PickMode.Extract, listOf(d.path)) }
                    }
                }
                if (isDir) {
                    ActionRow(Icons.Rounded.Star, if (d.path in vm.favorites) R.string.act_fav_remove else R.string.act_fav_add, 5) {
                        close { vm.toggleFavorite(d.path) }
                    }
                }
                ActionRow(Icons.Rounded.Link, R.string.act_copy_path, 6) {
                    close {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("path", d.path))
                        Toast.makeText(context, R.string.msg_path_copied, Toast.LENGTH_SHORT).show()
                    }
                }
                ActionRow(Icons.Rounded.Delete, R.string.act_delete, -1) { close { vm.dialog = DialogState.Delete(listOf(d.path)) } }
            }
        }
    }
}

/** Удержание при выделении нескольких файлов: любое действие применяется ко всем выбранным. */
@Composable
private fun MultiActionsDialog(vm: MainViewModel, d: DialogState.MultiActions) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val hasShell = d.paths.any { ShellFs.needsShell(it) }
    fun close(block: () -> Unit) {
        vm.dialog = null
        block()
    }
    Dialog(onDismissRequest = { vm.dialog = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(36.dp),
            color = cs.surfaceContainerHigh,
            modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
        ) {
            Column(Modifier.padding(vertical = 16.dp).heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
                Text(
                    stringResource(R.string.selected_count, d.paths.size),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp),
                )
                HorizontalDivider(Modifier.padding(vertical = 10.dp, horizontal = 22.dp))
                ActionRow(Icons.Rounded.ContentCopy, R.string.act_copy, 0) { close { vm.startCopyOf(d.paths, false) } }
                ActionRow(Icons.Rounded.ContentCut, R.string.act_move, 1) { close { vm.startCopyOf(d.paths, true) } }
                ActionRow(Icons.Rounded.ContentCopy, R.string.act_copy_to, 2) { close { vm.dialog = DialogState.PickFolder(PickMode.Copy, d.paths) } }
                ActionRow(Icons.Rounded.ContentCut, R.string.act_move_to, 3) { close { vm.dialog = DialogState.PickFolder(PickMode.Move, d.paths) } }
                ActionRow(Icons.Rounded.PushPin, R.string.act_pin_toggle, 4) { close { vm.togglePinSelected() } }
                if (!hasShell) {
                    ActionRow(Icons.Rounded.FolderZip, R.string.act_compress, 5) { close { vm.dialog = DialogState.Compress(d.paths) } }
                    ActionRow(Icons.Rounded.Share, R.string.act_share, 6) { close { shareFiles(context, d.paths) } }
                }
                ActionRow(Icons.Rounded.Delete, R.string.act_delete, -1) { close { vm.dialog = DialogState.Delete(d.paths) } }
            }
        }
    }
}

/** Строка действия с цветным значком; [colorIndex] = -1 — опасное действие (красное). */
@Composable
private fun ActionRow(icon: ImageVector, label: Int, colorIndex: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = if (colorIndex < 0) cs.errorContainer to cs.onErrorContainer else blobColors(colorIndex)
    Row(
        Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBlob(icon, bg, fg, 40.dp, 14.dp)
        Spacer(Modifier.width(16.dp))
        Text(stringResource(label), fontWeight = FontWeight.Medium, color = if (colorIndex < 0) cs.error else cs.onSurface)
    }
}
