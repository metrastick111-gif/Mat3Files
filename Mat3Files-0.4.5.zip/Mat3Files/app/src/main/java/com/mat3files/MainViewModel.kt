package com.mat3files

import android.app.Application
import android.media.MediaScannerConnection
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PendingOp(val paths: List<String>, val move: Boolean)
data class OpProgress(val titleRes: Int, val done: Long, val total: Long)
data class ViewerState(val paths: List<String>, val index: Int)

enum class PickMode { Copy, Move, Extract }

sealed interface DialogState {
    data class Actions(val path: String) : DialogState
    data class MultiActions(val paths: List<String>) : DialogState
    data class InstallApk(val path: String) : DialogState
    data class Delete(val paths: List<String>) : DialogState
    data class Rename(val path: String) : DialogState
    data class NewFolder(val parent: String) : DialogState
    data class NewFile(val parent: String) : DialogState
    data class Details(val path: String) : DialogState
    data class Compress(val paths: List<String>) : DialogState
    data class ArchiveInfo(val path: String) : DialogState
    data class PickFolder(val mode: PickMode, val paths: List<String>) : DialogState
    data class Unsaved(val path: String) : DialogState
    data object EmptyTrash : DialogState
    data object RootInfo : DialogState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()
    val prefs = Prefs(app)
    val trash = TrashStore(app)

    // ── навигация ──
    val rootPath: String = Environment.getExternalStorageDirectory().absolutePath
    val stack = mutableStateListOf<Screen>(Screen.Folder(rootPath))
    val current: Screen get() = stack.last()

    // ── индекс и память ──
    var index by mutableStateOf<List<FileItem>>(emptyList()); private set
    var sections by mutableStateOf<Map<Section, List<FileItem>>>(emptyMap()); private set
    var storageTotal by mutableLongStateOf(0L); private set
    var storageFree by mutableLongStateOf(0L); private set
    var rootTotal by mutableLongStateOf(0L); private set
    var rootFree by mutableLongStateOf(0L); private set
    var roots by mutableStateOf<List<Root>>(emptyList()); private set
    private var loading = false

    // ── настройки просмотра ──
    var grid by mutableStateOf(prefs.grid)
    var sortBy by mutableIntStateOf(prefs.sortBy)
    var sortDesc by mutableStateOf(prefs.sortDesc)
    var showHidden by mutableStateOf(prefs.showHidden)
    var favorites by mutableStateOf(prefs.favorites)
    var pinned by mutableStateOf(prefs.pinned)
    var sectionOrder by mutableStateOf(loadSectionOrder())
        private set
    var density by mutableIntStateOf(prefs.density)
    var foldersFirst by mutableStateOf(prefs.foldersFirst)

    // ── закрепление файлов ──
    fun togglePin(path: String) {
        pinned = if (path in pinned) pinned - path else pinned + path
        prefs.pinned = pinned
    }

    fun togglePinSelected() {
        val paths = selected.toList()
        val allPinned = paths.all { it in pinned }
        pinned = if (allPinned) pinned - paths.toSet() else pinned + paths
        prefs.pinned = pinned
        selected.clear()
    }

    // ── порядок разделов (перетаскивание) ──
    private fun loadSectionOrder(): List<Section> {
        val saved = prefs.sectionOrder.split(',').mapNotNull { n -> Section.entries.firstOrNull { it.name == n } }
        return saved + Section.entries.filter { it !in saved }
    }

    fun moveSection(from: Section, to: Section) {
        val list = sectionOrder.toMutableList()
        val target = list.indexOf(to)
        list.remove(from)
        list.add(target.coerceIn(0, list.size), from)
        sectionOrder = list
        prefs.sectionOrder = list.joinToString(",") { it.name }
    }

    // ── терминал ──
    val terminal = TerminalSession(app, viewModelScope)

    fun openTerminal(cwd: String? = null) {
        if (cwd != null) terminal.cwd = cwd
        if (current !is Screen.Terminal) push(Screen.Terminal)
    }

    fun runInTerminal(path: String, mode: Int) {
        selected.clear()
        if (current !is Screen.Terminal) push(Screen.Terminal)
        terminal.runFile(path, mode)
    }

    // ── обновления ──
    var updateState by mutableStateOf<Update.State>(Update.State.Idle)
        private set

    fun checkUpdate() {
        if (updateState is Update.State.Checking) return
        updateState = Update.State.Checking
        viewModelScope.launch {
            val code = try {
                androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
            } catch (_: Exception) {
                0L
            }
            updateState = Update.check(code)
        }
    }

    /** Тексты сообщений-ошибок: для них уведомление показывается красным. */
    fun errorMessages(): Set<String> = setOf(
        R.string.msg_error, R.string.msg_need_shell, R.string.msg_exists, R.string.msg_into_itself, R.string.msg_no_app,
    ).map { ctx.getString(it) }.toSet()

    // ── тема ──
    var theme by mutableStateOf(
        ThemeSettings(prefs.themeMode, prefs.amoled, prefs.colorSource, prefs.preset, prefs.customHue, prefs.customSat),
    )
        private set

    fun setThemeMode(v: Int) { prefs.themeMode = v; theme = theme.copy(mode = v) }
    fun setAmoled(v: Boolean) { prefs.amoled = v; theme = theme.copy(amoled = v) }
    fun setColorSource(v: Int) { prefs.colorSource = v; theme = theme.copy(source = v) }
    fun setPreset(v: Int) { prefs.preset = v; theme = theme.copy(preset = v) }
    fun setCustomColor(hue: Float, sat: Float) {
        prefs.customHue = hue
        prefs.customSat = sat
        theme = theme.copy(customHue = hue, customSat = sat)
    }
    fun changeDensity(v: Int) { prefs.density = v; density = v }
    fun changeFoldersFirst(v: Boolean) { prefs.foldersFirst = v; foldersFirst = v }

    // ── фильтры, поиск ──
    var typeFilter by mutableStateOf<Kind?>(null)
    var showFilters by mutableStateOf(false)
    var searchQuery by mutableStateOf("")
    var searchHere by mutableStateOf(false)
    var searchKind by mutableStateOf<Kind?>(null)

    // ── Shizuku / root ──
    fun setRoot(enabled: Boolean) {
        prefs.rootEnabled = enabled
        Shell.rootEnabled = enabled
        if (enabled) viewModelScope.launch { Shell.checkRoot() }
    }

    // ── выбор, буфер, диалоги ──
    val selected = mutableStateListOf<String>()
    var pending by mutableStateOf<PendingOp?>(null); private set
    var dialog by mutableStateOf<DialogState?>(null)
    var viewer by mutableStateOf<ViewerState?>(null)
    var query by mutableStateOf("")
    var refreshTick by mutableIntStateOf(0); private set

    // ── редакторы ──
    private val editors = HashMap<String, EditorState>()
    fun editor(path: String): EditorState = editors.getOrPut(path) { EditorState(path) }

    // ── прогресс операций и сообщения ──
    var op by mutableStateOf<OpProgress?>(null); private set
    private var opJob: Job? = null
    val messages = Channel<String>(Channel.BUFFERED)

    init {
        Shell.rootEnabled = prefs.rootEnabled
        if (prefs.rootEnabled) viewModelScope.launch { Shell.checkRoot() }
        // записи старше 30 дней удаляем из корзины насовсем
        viewModelScope.launch(Dispatchers.IO) {
            trash.expired().forEach { e ->
                File(e.stored).deleteRecursively()
                trash.remove(e.id)
            }
        }
    }

    fun reload() {
        if (loading) return
        loading = true
        viewModelScope.launch {
            try {
                val items = Index.load(ctx)
                val secs = withContext(Dispatchers.Default) { Section.entries.associateWith { it.filter(items) } }
                index = items
                sections = secs
                val (total, free) = Index.storage()
                storageTotal = total
                storageFree = free
                val (rTotal, rFree) = Index.storageOf("/")
                rootTotal = rTotal
                rootFree = rFree
                roots = Index.roots(ctx)
            } finally {
                loading = false
            }
        }
    }

    // ── навигация ──
    fun push(screen: Screen) {
        selected.clear()
        stack.add(screen)
    }

    /** Открыть корень носителя как главный экран. */
    fun openRoot(path: String) {
        selected.clear()
        stack.clear()
        stack.add(Screen.Folder(path))
    }

    /** Показать содержащую папку для найденного файла. */
    fun openContaining(path: String) {
        val parent = File(path).parent ?: return
        if (stack.lastOrNull() is Screen.Search) stack.removeAt(stack.lastIndex)
        push(Screen.Folder(parent))
    }

    /** Кнопка «назад»: шаг по истории, а если истории нет — в родительскую папку. */
    fun up() {
        val top = stack.lastOrNull()
        if (stack.size > 1) {
            back()
        } else if (top is Screen.Folder && top.path != rootPath && top.path != "/") {
            File(top.path).parent?.let { stack[stack.lastIndex] = Screen.Folder(it) }
        }
    }

    fun canGoBack() = viewer != null || selected.isNotEmpty() || query.isNotBlank() || stack.size > 1

    fun back() {
        when {
            viewer != null -> viewer = null
            selected.isNotEmpty() -> selected.clear()
            query.isNotBlank() -> query = ""
            stack.size > 1 -> {
                val top = stack.last()
                if (top is Screen.Editor) {
                    if (editors[top.path]?.dirty == true) {
                        dialog = DialogState.Unsaved(top.path)
                        return
                    }
                    editors.remove(top.path)
                }
                stack.removeAt(stack.lastIndex)
                selected.clear()
            }
        }
    }

    /** Закрыть редактор (после сохранения или отказа от изменений). */
    fun closeEditor(path: String) {
        editors.remove(path)
        val top = stack.lastOrNull()
        if (top is Screen.Editor && top.path == path && stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun saveEditor(path: String, then: () -> Unit) {
        val st = editors[path] ?: return
        viewModelScope.launch {
            if (st.save()) {
                messages.trySend(ctx.getString(R.string.msg_saved))
                then()
            } else {
                messages.trySend(ctx.getString(R.string.msg_error))
            }
        }
    }

    // ── сортировка ──
    fun sorted(items: List<FileItem>): List<FileItem> {
        val base: Comparator<FileItem> = when (sortBy) {
            1 -> compareBy<FileItem> { it.modified }
            2 -> compareBy<FileItem> { if (it.isDir) it.children.toLong() else it.size }
            3 -> compareBy<FileItem> { it.kind.ordinal }.thenBy { it.name.substringAfterLast('.', "").lowercase() }
            else -> compareBy<FileItem> { it.name.lowercase() }
        }
        val ordered = if (sortDesc) base.reversed() else base
        // папки всегда выше файлов
        val pinnedFirst = compareByDescending<FileItem> { it.path in pinned }
        return if (foldersFirst) {
            items.sortedWith(pinnedFirst.thenByDescending { it.isDir }.then(ordered))
        } else {
            items.sortedWith(pinnedFirst.then(ordered))
        }
    }

    fun setSort(by: Int) {
        if (sortBy == by) sortDesc = !sortDesc else sortBy = by
        prefs.sortBy = sortBy
        prefs.sortDesc = sortDesc
    }

    fun toggleGrid() {
        grid = !grid
        prefs.grid = grid
    }

    fun toggleHidden() {
        showHidden = !showHidden
        prefs.showHidden = showHidden
        refreshTick++
    }

    fun toggleFavorite(path: String) {
        favorites = if (path in favorites) favorites - path else favorites + path
        prefs.favorites = favorites
        selected.clear()
    }

    // ── выбор ──
    fun toggleSelect(path: String) {
        if (path in selected) selected.remove(path) else selected.add(path)
    }

    fun selectAll(paths: List<String>) {
        selected.clear()
        selected.addAll(paths)
    }

    // ── копирование / перемещение ──
    fun startCopy(move: Boolean) {
        if (selected.isEmpty()) return
        pending = PendingOp(selected.toList(), move)
        selected.clear()
    }

    fun startCopyOf(paths: List<String>, move: Boolean) {
        selected.clear()
        pending = PendingOp(paths, move)
    }

    fun cancelPending() {
        pending = null
    }

    /** Скопировать или переместить сразу в выбранную папку (без хождения по экранам). */
    fun pasteInto(paths: List<String>, move: Boolean, dest: String) {
        selected.clear()
        pending = PendingOp(paths, move)
        paste(dest)
    }

    fun paste(destDir: String) {
        val p = pending ?: return
        pending = null
        val dest = File(destDir)
        val titleRes = if (p.move) R.string.op_moving else R.string.op_copying
        runOp(titleRes) { progress ->
            val plain = p.paths.filter { !ShellFs.needsShell(it) && File(it).exists() }
            val total = plain.sumOf { FileOps.totalSize(File(it)) }.coerceAtLeast(1L)
            var done = 0L
            val onBytes: (Long) -> Unit = { n ->
                done += n
                progress(done, total)
            }
            val touched = ArrayList<String>()
            var count = 0
            for ((i, srcPath) in p.paths.withIndex()) {
                // Android/data и Android/obb — только через Shizuku или root
                if (ShellFs.needsShell(srcPath) || ShellFs.needsShell(destDir)) {
                    if (!ShellFs.availableFor(srcPath) || !ShellFs.availableFor(destDir)) {
                        messages.trySend(ctx.getString(R.string.msg_need_shell))
                        continue
                    }
                    val target = ShellFs.uniqueTarget(destDir, srcPath.substringAfterLast('/'))
                    val ok = if (p.move) ShellFs.mv(srcPath, target) else ShellFs.cp(srcPath, target)
                    if (ok) {
                        count++
                        touched.add(target)
                        if (p.move) touched.add(srcPath)
                    }
                    progress((i + 1).toLong(), p.paths.size.toLong())
                    continue
                }
                val src = File(srcPath)
                if (!src.exists()) continue
                if (src.isDirectory && FileOps.isInside(src, dest)) {
                    messages.trySend(ctx.getString(R.string.msg_into_itself))
                    continue
                }
                // перемещение в ту же папку ничего не меняет
                if (p.move && src.parentFile?.canonicalPath == dest.canonicalPath) continue
                val target = FileOps.uniqueTarget(dest, src.name)
                try {
                    if (p.move) FileOps.moveTree(src, target, onBytes) else FileOps.copyTree(src, target, onBytes)
                    touched.add(target.absolutePath)
                    if (p.move) touched.add(src.absolutePath)
                    count++
                } catch (e: CancellationException) {
                    target.deleteRecursively()
                    throw e
                }
            }
            scan(touched)
            ctx.getString(if (p.move) R.string.msg_done_move else R.string.msg_done_copy, count)
        }
    }

    // ── удаление: в корзину или навсегда ──
    private fun volumeRoot(path: String): String =
        roots.firstOrNull { path.startsWith(it.path + "/") }?.path ?: Environment.getExternalStorageDirectory().absolutePath

    fun delete(paths: List<String>, permanent: Boolean) {
        selected.clear()
        runOp(R.string.op_deleting) { progress ->
            var n = 0
            val files = paths.map { File(it) }
            files.forEachIndexed { i, f ->
                if (ShellFs.needsShell(f.absolutePath)) {
                    // в Android/data корзины нет: удаляем сразу
                    if (ShellFs.availableFor(f.absolutePath) && ShellFs.rm(f.absolutePath)) n++
                    else messages.trySend(ctx.getString(R.string.msg_need_shell))
                    progress((i + 1).toLong(), files.size.toLong())
                    return@forEachIndexed
                }
                if (!f.exists()) return@forEachIndexed
                if (permanent) {
                    if (f.deleteRecursively()) n++
                } else {
                    val dir = File(volumeRoot(f.absolutePath), ".Mat3Trash").apply { mkdirs() }
                    val id = System.currentTimeMillis().toString() + "_" + i
                    val stored = File(dir, id + "_" + f.name)
                    val size = FileOps.totalSize(f)
                    val isDir = f.isDirectory
                    FileOps.moveTree(f, stored) {}
                    trash.add(TrashEntry(id, f.name, f.absolutePath, stored.absolutePath, System.currentTimeMillis(), size, isDir))
                    n++
                }
                progress((i + 1).toLong(), files.size.toLong())
            }
            scan(paths)
            ctx.getString(R.string.msg_deleted, n)
        }
    }

    fun restoreFromTrash(id: String) {
        val e = trash.entries.firstOrNull { it.id == id } ?: return
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val parent = File(e.original).parentFile ?: return@withContext false
                    parent.mkdirs()
                    val target = FileOps.uniqueTarget(parent, e.name)
                    FileOps.moveTree(File(e.stored), target) {}
                    trash.remove(id)
                    scan(listOf(target.absolutePath))
                    true
                } catch (_: Exception) {
                    false
                }
            }
            messages.trySend(ctx.getString(if (ok) R.string.msg_restored else R.string.msg_error))
            refreshTick++
        }
    }

    fun deleteForever(id: String) {
        val e = trash.entries.firstOrNull { it.id == id } ?: return
        viewModelScope.launch(Dispatchers.IO) {
            File(e.stored).deleteRecursively()
            trash.remove(id)
        }
    }

    fun emptyTrash() {
        val all = trash.entries.toList()
        viewModelScope.launch(Dispatchers.IO) {
            all.forEach { File(it.stored).deleteRecursively() }
            trash.clear()
        }
        messages.trySend(ctx.getString(R.string.msg_trash_emptied))
    }

    // ── переименование, новая папка, новый файл ──
    fun rename(path: String, newName: String) {
        val name = newName.trim()
        val src = File(path)
        if (name.isEmpty() || name.contains('/') || name == src.name) return
        val dest = File(src.parentFile, name)
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                if (ShellFs.needsShell(path)) {
                    if (!ShellFs.availableFor(path)) false
                    else if (ShellFs.exists(dest.absolutePath)) null
                    else ShellFs.mv(path, dest.absolutePath)
                } else if (dest.exists()) null else src.renameTo(dest)
            }
            when (ok) {
                null -> messages.trySend(ctx.getString(R.string.msg_exists))
                true -> {
                    selected.clear()
                    scan(listOf(path, dest.absolutePath))
                    messages.trySend(ctx.getString(R.string.msg_renamed))
                    refreshTick++
                }
                false -> messages.trySend(ctx.getString(R.string.msg_error))
            }
        }
    }

    fun createFolder(parent: String, name: String) {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) return
        viewModelScope.launch {
            val dir = File(parent, n)
            val ok = withContext(Dispatchers.IO) {
                if (ShellFs.needsShell(parent)) {
                    if (!ShellFs.availableFor(parent)) false
                    else if (ShellFs.exists(dir.absolutePath)) null
                    else ShellFs.mkdir(dir.absolutePath)
                } else if (dir.exists()) null else dir.mkdirs()
            }
            when (ok) {
                null -> messages.trySend(ctx.getString(R.string.msg_exists))
                true -> {
                    messages.trySend(ctx.getString(R.string.msg_folder_created))
                    refreshTick++
                }
                false -> messages.trySend(ctx.getString(R.string.msg_error))
            }
        }
    }

    /** Новый пустой файл; текстовые и кодовые файлы сразу открываются в редакторе. */
    fun createFile(parent: String, name: String) {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) return
        viewModelScope.launch {
            val file = File(parent, n)
            val ok = withContext(Dispatchers.IO) {
                try {
                    if (ShellFs.needsShell(parent)) {
                        if (!ShellFs.availableFor(parent)) false
                        else if (ShellFs.exists(file.absolutePath)) null
                        else ShellFs.touch(file.absolutePath)
                    } else if (file.exists()) null else file.createNewFile()
                } catch (_: Exception) {
                    false
                }
            }
            when (ok) {
                null -> messages.trySend(ctx.getString(R.string.msg_exists))
                true -> {
                    scan(listOf(file.absolutePath))
                    messages.trySend(ctx.getString(R.string.msg_file_created))
                    refreshTick++
                    if (isEditableName(n)) push(Screen.Editor(file.absolutePath))
                }
                false -> messages.trySend(ctx.getString(R.string.msg_error))
            }
        }
    }

    // ── архивы ──
    fun compress(paths: List<String>, format: ArchiveFormat, name: String) {
        selected.clear()
        val first = File(paths.firstOrNull() ?: return)
        val dir = first.parentFile ?: return
        runOp(R.string.op_compressing) { progress ->
            val sources = paths.map { File(it) }.filter { it.exists() }
            val total = sources.sumOf { FileOps.totalSize(it) }.coerceAtLeast(1L)
            val base = name.trim().ifEmpty { first.nameWithoutExtension }
            val dest = FileOps.uniqueTarget(dir, base + format.ext)
            var done = 0L
            try {
                Archives.compress(sources, dest, format) { n ->
                    done += n
                    progress(done, total)
                }
            } catch (e: Exception) {
                dest.delete()
                throw e
            }
            scan(listOf(dest.absolutePath))
            ctx.getString(R.string.msg_archive_created, dest.name)
        }
    }

    fun extract(archivePath: String, destDir: String, subfolder: Boolean) {
        selected.clear()
        runOp(R.string.op_extracting) { progress ->
            val archive = File(archivePath)
            val target = if (subfolder) FileOps.uniqueTarget(File(destDir), Archives.baseName(archive.name)) else File(destDir)
            val (_, uncompressed) = Archives.list(archive, 0)
            val total = (if (uncompressed > 0) uncompressed else archive.length() * 2).coerceAtLeast(1L)
            var done = 0L
            try {
                Archives.extract(archive, target) { n ->
                    done += n
                    progress(done.coerceAtMost(total), total)
                }
            } catch (e: Exception) {
                if (subfolder) target.deleteRecursively()
                throw e
            }
            scan(listOf(target.absolutePath))
            ctx.getString(R.string.msg_extracted, target.name)
        }
    }

    // ── просмотр архива без распаковки ──
    private val archiveCache = HashMap<String, List<Archives.Entry>>()

    suspend fun archiveEntries(path: String): List<Archives.Entry> = withContext(Dispatchers.IO) {
        archiveCache.getOrPut(path) { Archives.list(File(path), Int.MAX_VALUE).first }
    }

    /** Достаём файл из архива во временную папку и открываем: картинка — в просмотрщике, текст — в редакторе. */
    fun openArchiveEntry(archive: String, entry: String) {
        viewModelScope.launch {
            try {
                val cache = File(ctx.externalCacheDir ?: ctx.cacheDir, "archive_open/" + kotlin.math.abs(archive.hashCode()))
                val dest = File(cache, entry.substringAfterLast('/'))
                withContext(Dispatchers.IO) { Archives.extractEntry(File(archive), entry, dest) }
                val kind = kindOf(dest.name, false)
                when {
                    kind == Kind.Image -> viewer = ViewerState(listOf(dest.absolutePath), 0)
                    isEditableName(dest.name) -> push(Screen.Editor(dest.absolutePath))
                    else -> openFile(ctx, dest.absolutePath)
                }
            } catch (_: Exception) {
                messages.trySend(ctx.getString(R.string.msg_error))
            }
        }
    }

    /** Файл из Android/data: копируем во временное место через Shizuku/root и открываем. */
    fun openShellFile(path: String) {
        viewModelScope.launch {
            val staged = withContext(Dispatchers.IO) { ShellFs.stage(path) }
            if (staged == null) {
                messages.trySend(ctx.getString(R.string.msg_error))
                return@launch
            }
            when {
                kindOf(staged.name, false) == Kind.Image -> viewer = ViewerState(listOf(staged.absolutePath), 0)
                Archives.formatOf(staged.name) != null -> push(Screen.ArchiveView(staged.absolutePath, ""))
                else -> openFile(ctx, staged.absolutePath)
            }
        }
    }

    fun cancelOp() {
        opJob?.cancel()
    }

    // ── вспомогательное ──
    private fun runOp(titleRes: Int, block: suspend (progress: (Long, Long) -> Unit) -> String) {
        opJob?.cancel()
        op = OpProgress(titleRes, 0, 0)
        opJob = viewModelScope.launch {
            try {
                val message = withContext(Dispatchers.IO) {
                    block { done, total -> op = OpProgress(titleRes, done, total) }
                }
                messages.trySend(message)
            } catch (e: CancellationException) {
                messages.trySend(ctx.getString(R.string.msg_cancelled))
            } catch (e: Exception) {
                messages.trySend(ctx.getString(R.string.msg_error))
            } finally {
                op = null
                refreshTick++
            }
        }
    }

    /** Сообщить системе об изменениях, чтобы MediaStore и другие приложения увидели новые файлы. */
    private fun scan(paths: List<String>) {
        if (paths.isEmpty()) return
        MediaScannerConnection.scanFile(ctx, paths.toTypedArray(), null) { _, _ -> }
        viewModelScope.launch {
            delay(800)
            reload()
        }
    }
}
