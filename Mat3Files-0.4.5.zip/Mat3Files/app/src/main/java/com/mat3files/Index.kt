package com.mat3files

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Быстрый индекс всех файлов через MediaStore: не нужно обходить диск вручную. */
object Index {
    suspend fun load(context: Context): List<FileItem> = withContext(Dispatchers.IO) {
        val out = ArrayList<FileItem>(20_000)
        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_MODIFIED)
        val selection = "${MediaStore.Files.FileColumns.SIZE} > 0 AND format != 12289"
        try {
            context.contentResolver.query(uri, projection, selection, null, null)?.use { c ->
                val iPath = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                while (c.moveToNext()) {
                    val path = c.getString(iPath) ?: continue
                    if (path.contains("/.") || path.contains("/Android/data/") || path.contains("/Android/obb/")) continue
                    val name = path.substringAfterLast('/')
                    out.add(FileItem(path, name, false, c.getLong(iSize), c.getLong(iDate) * 1000, kindOf(name, false)))
                }
            }
        } catch (_: Exception) {
        }
        out
    }

    /** Всего и свободно в основной памяти. */
    fun storage(): Pair<Long, Long> = try {
        val s = StatFs(Environment.getExternalStorageDirectory().path)
        s.totalBytes to s.availableBytes
    } catch (_: Exception) {
        0L to 0L
    }

    /** Всего и свободно в разделе, где лежит [path] (для корневого каталога — раздел «/»). */
    fun storageOf(path: String): Pair<Long, Long> = try {
        val s = StatFs(path)
        s.totalBytes to s.availableBytes
    } catch (_: Exception) {
        0L to 0L
    }

    /** Внутренняя память и SD-карта (если есть). */
    fun roots(context: Context): List<Root> {
        val list = ArrayList<Root>()
        val internal = Environment.getExternalStorageDirectory().absolutePath
        list.add(Root(R.string.root_memory, internal))
        context.getExternalFilesDirs(null).orEmpty().filterNotNull().forEach { dir ->
            val p = dir.absolutePath
            val cut = p.indexOf("/Android")
            if (cut > 0) {
                val root = p.substring(0, cut)
                if (root != internal && File(root).exists() && list.none { it.path == root }) {
                    list.add(Root(R.string.root_sd, root))
                }
            }
        }
        return list
    }
}
