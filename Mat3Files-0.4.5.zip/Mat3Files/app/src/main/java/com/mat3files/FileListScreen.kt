package com.mat3files

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Открывает боковую панель (бургер-меню). Подставляется в MainActivity. */
val LocalOpenDrawer = staticCompositionLocalOf<() -> Unit> { {} }

// ───────────────────────── Экран папки ─────────────────────────

@Composable
fun FolderScreen(vm: MainViewModel, path: String) {
    val shell = ShellFs.needsShell(path)
    val items by produceState(
        emptyList<FileItem>(), path, vm.refreshTick, vm.showHidden, Shell.shizuku, Shell.rootWorks, Shell.rootEnabled,
    ) {
        value = withContext(Dispatchers.IO) {
            when {
                !shell -> FileOps.list(path, vm.showHidden)
                ShellFs.availableFor(path) -> ShellFs.list(path).orEmpty().filter { vm.showHidden || !it.name.startsWith(".") }
                else -> emptyList()
            }
        }
    }
    val sorted = remember(items, vm.sortBy, vm.sortDesc, vm.foldersFirst, vm.typeFilter) {
        vm.sorted(items).filter { it.isDir || vm.typeFilter == null || it.kind == vm.typeFilter }
    }
    val openDrawer = LocalOpenDrawer.current

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (vm.selected.isNotEmpty()) {
                SelectionHeader(vm, sorted.map { it.path })
            } else {
                FolderTopBar(vm, path, openDrawer)
            }
            if (shell && !ShellFs.availableFor(path)) {
                NeedShellCard(vm, path)
            } else {
                ShortcutStrip(vm, path, sorted)
                if (ShellFs.isSystemPath(path) && !Shell.rootReady) RootHintCard(vm)
                FileListBody(
                    vm = vm,
                    items = sorted,
                    emptyText = stringResource(R.string.empty_folder),
                    emptyHint = stringResource(R.string.empty_hint),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )
            }
        }
        if (!shell || ShellFs.availableFor(path)) NewFab(vm, path, Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun NeedShellCard(vm: MainViewModel, path: String) {
    val cs = MaterialTheme.colorScheme
    val system = ShellFs.isSystemPath(path)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(30.dp))
            .background(cs.tertiaryContainer)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            stringResource(if (system) R.string.root_need_title else R.string.shell_need_title),
            color = cs.onTertiaryContainer, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium,
        )
        Text(
            stringResource(if (system) R.string.root_need_text else R.string.shell_need_text),
            color = cs.onTertiaryContainer.copy(alpha = 0.85f),
        )
        if (system) {
            WideButton(stringResource(R.string.root_enable), { vm.setRoot(true) })
        } else {
            WideButton(stringResource(R.string.shell_connect), { Shell.connectShizuku() })
        }
        WideButton(stringResource(R.string.shell_open_settings), { vm.push(Screen.Theme) }, tonal = true)
    }
}

/** Подсказка в корневом каталоге: смотреть можно, менять — только с Root. */
@Composable
private fun RootHintCard(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(cs.tertiaryContainer)
            .padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(stringResource(R.string.root_hint), color = cs.onTertiaryContainer, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        androidx.compose.material3.TextButton(onClick = { vm.setRoot(true) }) {
            Text(stringResource(R.string.root_enable), color = cs.onTertiaryContainer, fontWeight = FontWeight.Bold)
        }
    }
}

// ───────────────────────── Цветные блоки под панелью ─────────────────────────

@Composable
private fun ColorBlock(
    icon: ImageVector,
    title: String,
    subtitle: String,
    container: Color,
    content: Color,
    onClick: (() -> Unit)? = null,
) {
    Column(
        Modifier
            .then(if (onClick != null) Modifier.pressable(onClick) else Modifier)
            .clip(RoundedCornerShape(22.dp))
            .background(container)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = content, modifier = Modifier.size(20.dp))
            Text(title, color = content, fontWeight = FontWeight.Bold, maxLines = 1, style = MaterialTheme.typography.titleSmall)
        }
        Text(subtitle, color = content.copy(alpha = 0.75f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

/** Лента цветных блоков: сколько в папке, быстрые папки и закреплённое. */
@Composable
private fun ShortcutStrip(vm: MainViewModel, path: String, items: List<FileItem>) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val folders = items.count { it.isDir }
    val files = items.size - folders
    val total = items.filter { !it.isDir }.sumOf { it.size }
    val quick = remember(path, vm.rootPath) {
        if (path == vm.rootPath) {
            listOf("Download", "DCIM", "Pictures", "Movies", "Music", "Documents")
                .map { it to File(vm.rootPath, it) }
                .filter { it.second.isDirectory }
        } else {
            emptyList()
        }
    }
    val pinnedPaths = vm.pinned.toList().filter { it.startsWith("/") }
    androidx.compose.foundation.lazy.LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(bottom = 6.dp),
    ) {
        item { ColorBlock(Icons.Rounded.Folder, folders.toString(), stringResource(R.string.strip_folders), cs.primaryContainer, cs.onPrimaryContainer) }
        item { ColorBlock(Icons.AutoMirrored.Rounded.InsertDriveFile, files.toString(), stringResource(R.string.strip_files), cs.secondaryContainer, cs.onSecondaryContainer) }
        item { ColorBlock(Icons.Rounded.Storage, formatSize(total), stringResource(R.string.strip_size), cs.tertiaryContainer, cs.onTertiaryContainer) }
        items(quick) { (name, dir) ->
            ColorBlock(Icons.Rounded.Folder, name, stringResource(R.string.strip_quick), cs.primary, cs.onPrimary) {
                vm.push(Screen.Folder(dir.absolutePath))
            }
        }
        items(pinnedPaths) { p ->
            val f = File(p)
            ColorBlock(Icons.Rounded.PushPin, f.name.take(18), stringResource(R.string.strip_pinned), cs.secondary, cs.onSecondary) {
                val item = FileItem(p, f.name, f.isDirectory, f.length(), f.lastModified(), kindOf(f.name, f.isDirectory))
                openItem(vm, context, item, listOf(item))
            }
        }
    }
}

// ───────────────────────── Верхняя панель ─────────────────────────

@Composable
private fun FolderTopBar(vm: MainViewModel, path: String, onMenu: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onMenu, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.Menu, stringResource(R.string.menu)) }
        // «назад»: по истории, а если её нет — в родительскую папку
        AnimatedVisibility(
            visible = vm.stack.size > 1 || (path != vm.rootPath && path != "/"),
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
        ) {
            IconButton(onClick = vm::up, modifier = Modifier.size(42.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.act_back))
            }
        }
        PathBar(vm, path, Modifier.weight(1f).padding(horizontal = 2.dp))
        IconButton(onClick = { vm.push(Screen.Search) }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.Search, stringResource(R.string.search)) }
        IconButton(onClick = vm::toggleHidden, modifier = Modifier.size(42.dp)) {
            Icon(
                if (vm.showHidden) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                stringResource(R.string.show_hidden),
                tint = if (vm.showHidden) cs.primary else cs.onSurfaceVariant,
            )
        }
        IconButton(onClick = { vm.showFilters = true }, modifier = Modifier.size(42.dp)) {
            Icon(
                Icons.Rounded.Tune,
                stringResource(R.string.filters),
                tint = if (vm.typeFilter != null) cs.primary else cs.onSurfaceVariant,
            )
        }
    }
}

/** Путь посередине: /storage/emulated/0/Download. Нажатие на часть пути открывает эту папку. */
@Composable
private fun PathBar(vm: MainViewModel, path: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val scroll = rememberScrollState()
    LaunchedEffect(path) { scroll.animateScrollTo(scroll.maxValue) }
    val parts = if (path == "/") emptyList() else path.trim('/').split('/')
    Row(
        modifier
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(cs.surfaceContainerHigh)
            .horizontalScroll(scroll)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "/",
            color = if (parts.isEmpty()) cs.primary else cs.onSurface,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable(enabled = parts.isNotEmpty()) { vm.push(Screen.Folder("/")) }
                .padding(horizontal = 5.dp, vertical = 8.dp),
        )
        var acc = ""
        parts.forEachIndexed { i, part ->
            acc += "/$part"
            val target = acc
            val last = i == parts.lastIndex
            if (i > 0) Text("/", color = cs.outline, fontSize = 13.sp)
            Text(
                part,
                color = if (last) cs.primary else cs.onSurface,
                fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                fontSize = 13.sp,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(enabled = !last) { vm.push(Screen.Folder(target)) }
                    .padding(horizontal = 3.dp, vertical = 8.dp),
            )
        }
    }
}

// ───────────────────────── Фильтры и сортировка ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterSheet(vm: MainViewModel) {
    if (!vm.showFilters) return
    val cs = MaterialTheme.colorScheme
    ModalBottomSheet(onDismissRequest = { vm.showFilters = false }) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(stringResource(R.string.filters_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            SheetLabel(R.string.sort_by)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(R.string.sort_name, R.string.sort_date, R.string.sort_size, R.string.sort_type).forEachIndexed { i, res ->
                    FilterChip(
                        selected = vm.sortBy == i,
                        onClick = { vm.setSort(i) },
                        label = { Text(stringResource(res)) },
                        trailingIcon = {
                            if (vm.sortBy == i) {
                                Icon(if (vm.sortDesc) Icons.Rounded.ArrowDownward else Icons.Rounded.ArrowUpward, null, Modifier.size(18.dp))
                            }
                        },
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.folders_first), Modifier.weight(1f))
                Switch(checked = vm.foldersFirst, onCheckedChange = vm::changeFoldersFirst)
            }

            SheetLabel(R.string.view_mode)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !vm.grid,
                    onClick = { if (vm.grid) vm.toggleGrid() },
                    label = { Text(stringResource(R.string.view_list)) },
                    leadingIcon = { Icon(Icons.AutoMirrored.Rounded.ViewList, null, Modifier.size(18.dp)) },
                )
                FilterChip(
                    selected = vm.grid,
                    onClick = { if (!vm.grid) vm.toggleGrid() },
                    label = { Text(stringResource(R.string.view_grid)) },
                    leadingIcon = { Icon(Icons.Rounded.GridView, null, Modifier.size(18.dp)) },
                )
            }

            SheetLabel(R.string.filter_type)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val options = listOf(
                    R.string.filter_all to null,
                    R.string.sec_images to Kind.Image,
                    R.string.sec_videos to Kind.Video,
                    R.string.sec_audio to Kind.Audio,
                    R.string.sec_docs to Kind.Doc,
                    R.string.filter_code to Kind.Code,
                    R.string.sec_archives to Kind.Archive,
                    R.string.sec_apks to Kind.Apk,
                )
                options.forEach { (res, kind) ->
                    FilterChip(
                        selected = vm.typeFilter == kind,
                        onClick = { vm.typeFilter = kind },
                        label = { Text(stringResource(res)) },
                    )
                }
            }
            Text(
                stringResource(R.string.filter_hint),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SheetLabel(res: Int) {
    Text(
        stringResource(res),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 4.dp),
    )
}

// ───────────────────────── Раздел (категория) ─────────────────────────

@Composable
fun SectionScreen(vm: MainViewModel, section: Section) {
    val items = vm.sections[section].orEmpty()
    Column(Modifier.fillMaxSize()) {
        if (vm.selected.isNotEmpty()) {
            SelectionHeader(vm, items.map { it.path })
        } else {
            ScreenHeader(
                title = stringResource(section.title),
                subtitle = stringResource(R.string.section_stats, items.size, formatSize(items.sumOf { it.size })),
                onBack = vm::back,
            ) {
                IconButton(onClick = vm::toggleGrid) {
                    Icon(if (vm.grid) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView, null)
                }
            }
        }
        FileListBody(
            vm = vm,
            items = items,
            emptyText = stringResource(R.string.empty_folder),
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
    }
}

// ───────────────────────── Шапки ─────────────────────────

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String?,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.act_back)) }
        Column(Modifier.weight(1f)) {
            MiddleEllipsisText(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
            )
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
        actions()
    }
}

@Composable
fun SelectionHeader(vm: MainViewModel, allPaths: List<String>?) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(cs.secondaryContainer)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = { vm.selected.clear() }) {
            Icon(Icons.Rounded.Close, stringResource(R.string.act_close), tint = cs.onSecondaryContainer)
        }
        Text(
            stringResource(R.string.selected_count, vm.selected.size),
            color = cs.onSecondaryContainer,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (allPaths != null) {
            IconButton(onClick = { vm.selectAll(allPaths) }) {
                Icon(Icons.Rounded.SelectAll, stringResource(R.string.act_select_all), tint = cs.onSecondaryContainer)
            }
        }
    }
}

// ───────────────────────── Список и сетка ─────────────────────────

/** Единое поведение при нажатии на элемент списка. */
fun openItem(vm: MainViewModel, context: Context, item: FileItem, siblings: List<FileItem>) {
    val shell = ShellFs.needsShell(item.path)
    when {
        item.isDir -> vm.push(Screen.Folder(item.path))
        shell && isEditableName(item.name) -> vm.push(Screen.Editor(item.path))
        shell -> vm.openShellFile(item.path)
        !shell && item.name.endsWith(".apk", ignoreCase = true) -> vm.dialog = DialogState.InstallApk(item.path)
        item.kind == Kind.Image -> {
            val images = siblings.filter { it.kind == Kind.Image && !ShellFs.needsShell(it.path) }
            vm.viewer = ViewerState(images.map { it.path }, images.indexOfFirst { it.path == item.path }.coerceAtLeast(0))
        }
        // zip и другие архивы открываются как папка, без распаковки
        Archives.formatOf(item.name) != null -> vm.push(Screen.ArchiveView(item.path, ""))
        isEditableName(item.name) || (item.kind == Kind.Other && FileOps.looksLikeText(item.path)) ->
            vm.push(Screen.Editor(item.path))
        else -> openFile(context, item.path)
    }
}

@Composable
fun FileListBody(
    vm: MainViewModel,
    items: List<FileItem>,
    emptyText: String,
    modifier: Modifier = Modifier,
    emptyHint: String? = null,
) {
    val context = LocalContext.current
    val selectionMode = vm.selected.isNotEmpty()

    val click: (FileItem) -> Unit = { item ->
        if (selectionMode) vm.toggleSelect(item.path) else openItem(vm, context, item, items)
    }
    val longClick: (FileItem) -> Unit = { item ->
        if (selectionMode) {
            // удержание при выделении: действие применяется ко всем выбранным
            if (item.path !in vm.selected) vm.toggleSelect(item.path)
            val all = vm.selected.toList()
            vm.dialog = if (all.size == 1) DialogState.Actions(all[0]) else DialogState.MultiActions(all)
        } else {
            vm.dialog = DialogState.Actions(item.path)
        }
    }
    val swipe: (FileItem) -> Unit = { vm.toggleSelect(it.path) }

    if (items.isEmpty()) {
        val cs = MaterialTheme.colorScheme
        Column(
            modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier.size(120.dp).clip(RoundedCornerShape(40.dp)).background(cs.primaryContainer),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Folder, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(56.dp)) }
            Spacer(Modifier.height(18.dp))
            Text(emptyText, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (emptyHint != null) {
                Spacer(Modifier.height(4.dp))
                Text(emptyHint, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }
    val padding = PaddingValues(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 120.dp)
    if (vm.grid) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(104.dp),
            modifier = modifier,
            contentPadding = padding,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(items, key = { it.path }) { item ->
                FileTile(item, item.path in vm.selected, item.path in vm.pinned, { click(item) }, { longClick(item) }, { swipe(item) }, Modifier.animateItem())
            }
        }
    } else {
        LazyColumn(modifier = modifier, contentPadding = padding) {
            items(items, key = { it.path }) { item ->
                FileRow(item, item.path in vm.selected, item.path in vm.pinned, vm.density, { click(item) }, { longClick(item) }, { swipe(item) }, Modifier.animateItem())
            }
        }
    }
}

@Composable
fun FileRow(
    item: FileItem,
    selected: Boolean,
    pinned: Boolean,
    density: Int,
    onClick: () -> Unit,
    onLong: () -> Unit,
    onSwipe: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    // каждая строка слегка окрашена в цвет типа файла
    val tint = kindColors(item.kind).first
    val bg by animateColorAsState(
        if (selected) cs.secondaryContainer else tint.copy(alpha = 0.20f),
        label = "rowBg",
    )
    val thumb = listOf(40, 48, 56)[density.coerceIn(0, 2)].dp
    val vpad = listOf(4, 8, 12)[density.coerceIn(0, 2)].dp
    val subtitle = if (item.isDir) {
        stringResource(R.string.folder_items, item.children) + " · " + formatDate(item.modified)
    } else {
        formatSize(item.size) + " · " + formatDate(item.modified)
    }
    SwipeSelectBox(onSwipe, modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .pressable(onClick, onLong)
                .clip(RoundedCornerShape(20.dp))
                .background(bg)
                .padding(horizontal = 10.dp, vertical = vpad),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(contentAlignment = Alignment.Center) {
                FileThumb(item, thumb)
                SelectionMark(selected, Modifier.size(thumb))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                MiddleEllipsisText(
                    item.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            if (pinned) {
                Icon(Icons.Rounded.PushPin, null, tint = cs.primary, modifier = Modifier.padding(start = 8.dp).size(18.dp))
            }
        }
    }
}

@Composable
private fun FileTile(
    item: FileItem,
    selected: Boolean,
    pinned: Boolean,
    onClick: () -> Unit,
    onLong: () -> Unit,
    onSwipe: () -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = kindColors(item.kind)
    val packageDir = item.isDir && isPackageDir(item.path)
    SwipeSelectBox(onSwipe, modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().pressable(onClick, onLong)) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(bg),
                contentAlignment = Alignment.Center,
            ) {
                when {
                    (item.kind == Kind.Image || item.kind == Kind.Video) && !ShellFs.needsShell(item.path) -> AsyncImage(
                        model = File(item.path),
                        contentDescription = null,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                    item.kind == Kind.Apk || packageDir -> AppIcon(
                        key = if (packageDir) item.name else item.path,
                        isApk = !packageDir,
                        size = 80.dp,
                    ) { Icon(kindIcon(item.kind), null, tint = fg, modifier = Modifier.size(40.dp)) }
                    else -> Icon(kindIcon(item.kind), null, tint = fg, modifier = Modifier.size(40.dp))
                }
                SelectionMark(selected, Modifier.fillMaxSize())
                if (pinned) {
                    Icon(
                        Icons.Rounded.PushPin, null, tint = cs.primary,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp),
                    )
                }
            }
            MiddleEllipsisText(
                item.name,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurface,
                modifier = Modifier.padding(start = 4.dp, top = 4.dp, end = 4.dp),
            )
        }
    }
}

/** Галочка выбора: «выпрыгивает» поверх миниатюры. */
@Composable
private fun SelectionMark(selected: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    AnimatedVisibility(selected, enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
        Box(
            modifier.clip(RoundedCornerShape(14.dp)).background(cs.primary.copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(26.dp))
        }
    }
}

// ───────────────────────── Кнопка «+» ─────────────────────────

/** «+» крутится и раскрывается в две иконки: файл и папка. */
@Composable
private fun NewFab(vm: MainViewModel, path: String, modifier: Modifier) {
    var open by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        if (open) 135f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 260f), label = "fabRotation",
    )
    val cs = MaterialTheme.colorScheme
    AnimatedVisibility(
        visible = vm.selected.isEmpty() && vm.pending == null,
        modifier = modifier,
        enter = scaleIn() + fadeIn(),
        exit = scaleOut() + fadeOut(),
    ) {
        Column(
            Modifier.padding(16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AnimatedVisibility(
                visible = open,
                enter = fadeIn() + slideInVertically { it / 2 } + scaleIn(),
                exit = fadeOut() + slideOutVertically { it / 2 } + scaleOut(),
            ) {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SmallFloatingActionButton(
                        onClick = {
                            open = false
                            vm.dialog = DialogState.NewFile(path)
                        },
                        containerColor = cs.secondaryContainer,
                        contentColor = cs.onSecondaryContainer,
                    ) { Icon(Icons.Rounded.NoteAdd, stringResource(R.string.new_file)) }
                    SmallFloatingActionButton(
                        onClick = {
                            open = false
                            vm.dialog = DialogState.NewFolder(path)
                        },
                        containerColor = cs.tertiaryContainer,
                        contentColor = cs.onTertiaryContainer,
                    ) { Icon(Icons.Rounded.CreateNewFolder, stringResource(R.string.new_folder)) }
                }
            }
            FloatingActionButton(onClick = { open = !open }) {
                Icon(Icons.Rounded.Add, null, Modifier.graphicsLayer { rotationZ = rotation })
            }
        }
    }
}
