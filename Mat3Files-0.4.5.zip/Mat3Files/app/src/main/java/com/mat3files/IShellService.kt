package com.mat3files

import android.os.Binder
import android.os.IBinder
import android.os.IInterface
import android.os.Parcel

/**
 * Binder-интерфейс сервиса, который Shizuku запускает с правами shell.
 * Написан вручную (то же, что генерирует AIDL), чтобы сборке не нужен был инструмент aidl.
 */
interface IShellService : IInterface {
    fun destroy()
    fun exec(command: String): String

    /** Запустить процесс с потоковым выводом и вводом. Возвращает номер процесса. */
    fun start(command: String): Int

    /** Передать текст на stdin процесса. */
    fun write(id: Int, text: String)

    /** Ждать вывод. Обычный текст — кусок вывода; "\u0000КОД" — процесс завершён. */
    fun read(id: Int): String

    fun kill(id: Int)

    abstract class Stub : Binder(), IShellService {
        init {
            attachInterface(this, DESCRIPTOR)
        }

        override fun asBinder(): IBinder = this

        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            when (code) {
                IBinder.INTERFACE_TRANSACTION -> {
                    reply?.writeString(DESCRIPTOR)
                    return true
                }
                TRANSACTION_exec -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = exec(data.readString() ?: "")
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TRANSACTION_start -> {
                    data.enforceInterface(DESCRIPTOR)
                    val id = start(data.readString() ?: "")
                    reply?.writeNoException()
                    reply?.writeInt(id)
                    return true
                }
                TRANSACTION_write -> {
                    data.enforceInterface(DESCRIPTOR)
                    val id = data.readInt()
                    write(id, data.readString() ?: "")
                    reply?.writeNoException()
                    return true
                }
                TRANSACTION_read -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = read(data.readInt())
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TRANSACTION_kill -> {
                    data.enforceInterface(DESCRIPTOR)
                    kill(data.readInt())
                    reply?.writeNoException()
                    return true
                }
                TRANSACTION_destroy -> {
                    data.enforceInterface(DESCRIPTOR)
                    destroy()
                    reply?.writeNoException()
                    return true
                }
            }
            return super.onTransact(code, data, reply, flags)
        }

        companion object {
            const val DESCRIPTOR = "com.mat3files.IShellService"
            const val TRANSACTION_exec = IBinder.FIRST_CALL_TRANSACTION
            const val TRANSACTION_start = IBinder.FIRST_CALL_TRANSACTION + 1
            const val TRANSACTION_write = IBinder.FIRST_CALL_TRANSACTION + 2
            const val TRANSACTION_read = IBinder.FIRST_CALL_TRANSACTION + 3
            const val TRANSACTION_kill = IBinder.FIRST_CALL_TRANSACTION + 4
            // этот номер обязателен для Shizuku: так он останавливает пользовательский сервис
            const val TRANSACTION_destroy = 16777114

            fun asInterface(binder: IBinder?): IShellService? {
                if (binder == null) return null
                val local = binder.queryLocalInterface(DESCRIPTOR)
                return if (local is IShellService) local else ShellServiceProxy(binder)
            }
        }
    }
}

/** Клиентская часть: превращает вызовы методов в транзакции Binder. */
class ShellServiceProxy(private val remote: IBinder) : IShellService {
    override fun asBinder(): IBinder = remote

    override fun exec(command: String): String {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IShellService.Stub.DESCRIPTOR)
            data.writeString(command)
            remote.transact(IShellService.Stub.TRANSACTION_exec, data, reply, 0)
            reply.readException()
            return reply.readString() ?: ""
        } finally {
            reply.recycle()
            data.recycle()
        }
    }

    override fun start(command: String): Int {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IShellService.Stub.DESCRIPTOR)
            data.writeString(command)
            remote.transact(IShellService.Stub.TRANSACTION_start, data, reply, 0)
            reply.readException()
            return reply.readInt()
        } finally {
            reply.recycle()
            data.recycle()
        }
    }

    override fun write(id: Int, text: String) {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IShellService.Stub.DESCRIPTOR)
            data.writeInt(id)
            data.writeString(text)
            remote.transact(IShellService.Stub.TRANSACTION_write, data, reply, 0)
            reply.readException()
        } finally {
            reply.recycle()
            data.recycle()
        }
    }

    override fun read(id: Int): String {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IShellService.Stub.DESCRIPTOR)
            data.writeInt(id)
            remote.transact(IShellService.Stub.TRANSACTION_read, data, reply, 0)
            reply.readException()
            return reply.readString() ?: ""
        } finally {
            reply.recycle()
            data.recycle()
        }
    }

    override fun kill(id: Int) {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IShellService.Stub.DESCRIPTOR)
            data.writeInt(id)
            remote.transact(IShellService.Stub.TRANSACTION_kill, data, reply, 0)
            reply.readException()
        } finally {
            reply.recycle()
            data.recycle()
        }
    }

    override fun destroy() {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IShellService.Stub.DESCRIPTOR)
            remote.transact(IShellService.Stub.TRANSACTION_destroy, data, reply, 0)
            reply.readException()
        } finally {
            reply.recycle()
            data.recycle()
        }
    }
}
