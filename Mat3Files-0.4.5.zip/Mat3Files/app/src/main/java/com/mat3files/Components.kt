package com.mat3files

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import java.io.File

/** Нажатие с «пружинкой»; долгое нажатие — для выбора файлов. */
@Composable
fun Modifier.pressable(onClick: () -> Unit, onLongClick: (() -> Unit)? = null): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 600f),
        label = "press",
    )
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLongClick)
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onTap = { click() },
                onLongPress = { long?.invoke() },
            )
        }
}

fun kindIcon(kind: Kind): ImageVector = when (kind) {
    Kind.Folder -> Icons.Rounded.Folder
    Kind.Image -> Icons.Rounded.Image
    Kind.Video -> Icons.Rounded.Movie
    Kind.Audio -> Icons.Rounded.MusicNote
    Kind.Doc -> Icons.Rounded.Description
    Kind.Code -> Icons.Rounded.Code
    Kind.Archive -> Icons.Rounded.FolderZip
    Kind.Apk -> Icons.Rounded.Android
    Kind.Other -> Icons.AutoMirrored.Rounded.InsertDriveFile
}

/** Цвета типа файла берём из динамической палитры: насыщенные, чтобы список не выглядел блёклым. */
@Composable
fun kindColors(kind: Kind): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (kind) {
        Kind.Folder -> cs.primary to cs.onPrimary
        Kind.Image -> cs.tertiary to cs.onTertiary
        Kind.Video -> cs.error to cs.onError
        Kind.Audio -> cs.secondary to cs.onSecondary
        Kind.Doc -> cs.primaryContainer to cs.onPrimaryContainer
        Kind.Code -> cs.tertiaryContainer to cs.onTertiaryContainer
        Kind.Archive -> cs.secondaryContainer to cs.onSecondaryContainer
        Kind.Apk -> cs.primaryContainer to cs.onPrimaryContainer
        Kind.Other -> cs.surfaceContainerHighest to cs.onSurfaceVariant
    }
}

/** Папка вида Android/data/<пакет>: показываем значок установленного приложения. */
fun isPackageDir(path: String) = Regex(".*/Android/(data|obb|media)/[^/]+$").matches(path)

/** Миниатюра: картинка или кадр видео, значок приложения у APK и у папок пакетов, иначе цветная иконка типа. */
@Composable
fun FileThumb(item: FileItem, size: Dp, modifier: Modifier = Modifier, corner: Dp = 14.dp) {
    val (bg, fg) = kindColors(item.kind)
    val shape = RoundedCornerShape(corner)
    val packageDir = item.isDir && isPackageDir(item.path)
    Box(modifier.size(size).clip(shape).background(bg), contentAlignment = Alignment.Center) {
        when {
            (item.kind == Kind.Image || item.kind == Kind.Video) && !ShellFs.needsShell(item.path) -> AsyncImage(
                model = File(item.path),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size),
            )
            item.kind == Kind.Apk || packageDir -> AppIcon(
                key = if (packageDir) item.name else item.path,
                isApk = !packageDir,
                size = size,
            ) { Icon(kindIcon(item.kind), null, tint = fg, modifier = Modifier.size(size * 0.5f)) }
            else -> Icon(kindIcon(item.kind), null, tint = fg, modifier = Modifier.size(size * 0.5f))
        }
    }
}

/** Загрузка значков приложений: из APK-файла или по имени установленного пакета. */
object AppIcons {
    private val cache = LruCache<String, ImageBitmap>(300)

    fun cached(key: String): ImageBitmap? = cache.get(key)

    suspend fun load(context: Context, key: String, isApk: Boolean): ImageBitmap? = withContext(Dispatchers.IO) {
        cache.get(key)?.let { return@withContext it }
        val pm = context.packageManager
        val icon = try {
            if (isApk) {
                val info = pm.getPackageArchiveInfo(key, 0) ?: return@withContext null
                val app = info.applicationInfo ?: return@withContext null
                app.sourceDir = key
                app.publicSourceDir = key
                app.loadIcon(pm)
            } else {
                pm.getApplicationIcon(key)
            }
        } catch (_: Throwable) {
            null
        }
        val bmp = icon?.toBitmap(96, 96)?.asImageBitmap()
        if (bmp != null) cache.put(key, bmp)
        bmp
    }
}

@Composable
fun AppIcon(key: String, isApk: Boolean, size: Dp, fallback: @Composable () -> Unit) {
    val context = LocalContext.current
    val icon by produceState(AppIcons.cached(key), key) {
        if (value == null) value = AppIcons.load(context, key, isApk)
    }
    val bmp = icon
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size * 0.82f))
    } else {
        fallback()
    }
}

// ───────── длинные названия: «начало…конец.zip» ─────────

private fun fitMiddle(measurer: TextMeasurer, text: String, style: TextStyle, maxPx: Int): String {
    fun width(t: String) = measurer.measure(t, style, softWrap = false, maxLines = 1).size.width
    if (maxPx <= 0 || width(text) <= maxPx) return text
    val dot = text.lastIndexOf('.')
    val tail = if (dot > 0 && text.length - dot <= 8) text.takeLast(text.length - dot + 3) else text.takeLast(4)
    var lo = 1
    var hi = (text.length - tail.length).coerceAtLeast(1)
    var best = 1
    while (lo <= hi) {
        val mid = (lo + hi) / 2
        if (width(text.take(mid) + "…" + tail) <= maxPx) {
            best = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return text.take(best) + "…" + tail
}

/** Название, которое сокращается посередине и сохраняет расширение: «длинноеназв…ие.zip». */
@Composable
fun MiddleEllipsisText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
) {
    val measurer = rememberTextMeasurer()
    val merged = style.merge(TextStyle(color = color, fontWeight = fontWeight))
    BoxWithConstraints(modifier) {
        val maxPx = constraints.maxWidth
        val shown = remember(text, maxPx, merged) { fitMiddle(measurer, text, merged, maxPx) }
        Text(shown, style = merged, maxLines = 1, softWrap = false)
    }
}

// ───────── свайп слева направо — выбрать файл ─────────

@Composable
fun SwipeSelectBox(onSelect: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val threshold = with(density) { 72.dp.toPx() }
    val limit = with(density) { 120.dp.toPx() }
    var dx by remember { mutableFloatStateOf(0f) }
    val shift by animateFloatAsState(dx, spring(dampingRatio = 0.7f, stiffness = 500f), label = "swipe")
    val select by rememberUpdatedState(onSelect)
    val progress = (shift / threshold).coerceIn(0f, 1f)
    Box(modifier) {
        if (shift > 4f) {
            Box(
                Modifier.matchParentSize().clip(RoundedCornerShape(20.dp)).background(cs.primaryContainer.copy(alpha = progress)),
                contentAlignment = Alignment.CenterStart,
            ) {
                Icon(
                    Icons.Rounded.Check, null, tint = cs.onPrimaryContainer,
                    modifier = Modifier.padding(start = 18.dp).graphicsLayer { scaleX = progress; scaleY = progress },
                )
            }
        }
        Box(
            Modifier
                .offset { IntOffset(shift.roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (dx >= threshold) {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                select()
                            }
                            dx = 0f
                        },
                        onDragCancel = { dx = 0f },
                    ) { change, amount ->
                        if (amount > 0f || dx > 0f) {
                            change.consume()
                            dx = (dx + amount * 0.7f).coerceIn(0f, limit)
                        }
                    }
                },
        ) { content() }
    }
}

// ───────── открыть / поделиться ─────────

private fun uriFor(context: Context, path: String) =
    FileProvider.getUriForFile(context, context.packageName + ".files", File(path))

fun openFile(context: Context, path: String) {
    val file = File(path)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uriFor(context, path), mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, R.string.msg_no_app, Toast.LENGTH_SHORT).show()
    }
}

fun shareFiles(context: Context, paths: List<String>) {
    val files = paths.filter { File(it).isFile }
    if (files.isEmpty()) return
    val uris = ArrayList(files.map { uriFor(context, it) })
    val intent = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
    }
    intent.type = "*/*"
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
