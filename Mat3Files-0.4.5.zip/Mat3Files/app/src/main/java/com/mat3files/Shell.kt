package com.mat3files

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Environment
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

/** Сервис, который Shizuku запускает в отдельном процессе с правами shell. */
class ShellService : IShellService.Stub() {
    override fun destroy() {
        System.exit(0)
    }

    override fun exec(command: String): String =
        try {
            val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            "$code\n$out"
        } catch (e: Exception) {
            "-1\n" + e.message
        }

    private class Proc(val process: Process, val reader: java.io.Reader)

    private val procs = java.util.concurrent.ConcurrentHashMap<Int, Proc>()
    private val nextId = java.util.concurrent.atomic.AtomicInteger(1)

    override fun start(command: String): Int {
        val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
        val id = nextId.getAndIncrement()
        procs[id] = Proc(p, java.io.InputStreamReader(p.inputStream, Charsets.UTF_8))
        return id
    }

    override fun write(id: Int, text: String) {
        val p = procs[id]?.process ?: return
        try {
            p.outputStream.write(text.toByteArray(Charsets.UTF_8))
            p.outputStream.flush()
        } catch (_: Exception) {
        }
    }

    override fun read(id: Int): String {
        val pr = procs[id] ?: return "\u0000-1"
        return try {
            val buf = CharArray(4096)
            val n = pr.reader.read(buf)
            if (n < 0) {
                val code = pr.process.waitFor()
                procs.remove(id)
                "\u0000$code"
            } else {
                String(buf, 0, n)
            }
        } catch (_: Exception) {
            procs.remove(id)
            "\u0000-1"
        }
    }

    override fun kill(id: Int) {
        procs[id]?.process?.destroy()
    }
}

enum class ShizukuState { Unavailable, NotRunning, NoPermission, Connecting, Connected }

/**
 * Единая точка выполнения команд с повышенными правами: Shizuku (shell) или root (su).
 * Через неё работают папки Android/data и Android/obb.
 */
object Shell {
    private const val REQUEST_CODE = 4242
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    var shizuku by mutableStateOf(ShizukuState.Unavailable); private set
    var rootEnabled by mutableStateOf(false)
    var rootWorks by mutableStateOf(false); private set

    @Volatile private var service: IShellService? = null
    private var appContext: Context? = null

    val available: Boolean get() = service != null || (rootEnabled && rootWorks)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IShellService.Stub.asInterface(binder)
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            refresh()
        }
    }

    fun init(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        try {
            Shizuku.addBinderReceivedListenerSticky { refresh(); bindIfPermitted() }
            Shizuku.addBinderDeadListener { service = null; refresh() }
            Shizuku.addRequestPermissionResultListener { _, result ->
                if (result == PackageManager.PERMISSION_GRANTED) bindIfPermitted()
                refresh()
            }
        } catch (_: Throwable) {
        }
        refresh()
    }

    fun shizukuInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (_: Exception) {
        false
    }

    fun refresh() {
        shizuku = try {
            when {
                service != null -> ShizukuState.Connected
                !Shizuku.pingBinder() -> if (appContext?.let { shizukuInstalled(it) } == true) ShizukuState.NotRunning else ShizukuState.Unavailable
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> ShizukuState.NoPermission
                else -> ShizukuState.Connecting
            }
        } catch (_: Throwable) {
            ShizukuState.Unavailable
        }
    }

    /** Запросить разрешение у Shizuku (если нужно) и подключиться к сервису. */
    fun connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                refresh()
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) bindIfPermitted()
            else Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
        refresh()
    }

    private fun bindIfPermitted() {
        val context = appContext ?: return
        try {
            if (service != null || !Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return
            val args = Shizuku.UserServiceArgs(ComponentName(context.packageName, ShellService::class.java.name))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(2)
            Shizuku.bindUserService(args, connection)
        } catch (_: Throwable) {
        }
    }

    fun openShizukuApp(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) ?: return
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ── root ──

    suspend fun checkRoot(): Boolean = withContext(Dispatchers.IO) {
        val ok = try {
            val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
            p.inputStream.bufferedReader().readText().contains("uid=0") && p.waitFor() == 0
        } catch (_: Exception) {
            false
        }
        rootWorks = ok
        ok
    }

    // ── выполнение команд ──

    val rootReady: Boolean get() = rootEnabled && rootWorks

    /** Результат: код выхода и вывод. null — нет доступа ни через Shizuku, ни через root. */
    fun exec(command: String, preferRoot: Boolean = false): Pair<Int, String>? {
        if (preferRoot) return execRoot(command) ?: execService(command)
        return execService(command) ?: execRoot(command)
    }

    fun execService(command: String): Pair<Int, String>? {
        val s = service ?: return null
        return try {
            parse(s.exec(command))
        } catch (_: Exception) {
            null
        }
    }

    // ── потоковое выполнение через Shizuku (для терминала: вывод по мере появления и ввод) ──

    fun svcStart(command: String): Int? = try { service?.start(command) } catch (_: Exception) { null }
    fun svcWrite(id: Int, text: String) { try { service?.write(id, text) } catch (_: Exception) { } }
    fun svcRead(id: Int): String? = try { service?.read(id) } catch (_: Exception) { null }
    fun svcKill(id: Int) { try { service?.kill(id) } catch (_: Exception) { } }

    fun execRoot(command: String): Pair<Int, String>? {
        if (!rootReady) return null
        return try {
            val p = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor() to out
        } catch (_: Exception) {
            null
        }
    }

    /** Процесс для терминала: обычный sh или su (потоковый вывод). */
    fun startProcess(command: String, cwd: String, root: Boolean): Process {
        val full = "cd " + ShellFs.q(cwd) + " 2>/dev/null; " + command
        return if (root) {
            ProcessBuilder("su", "-c", full).redirectErrorStream(true).start()
        } else {
            ProcessBuilder("sh", "-c", full).redirectErrorStream(true).start()
        }
    }

    private fun parse(raw: String): Pair<Int, String> {
        val nl = raw.indexOf('\n')
        if (nl < 0) return (raw.trim().toIntOrNull() ?: -1) to ""
        return (raw.substring(0, nl).trim().toIntOrNull() ?: -1) to raw.substring(nl + 1)
    }

    // ── сведения об устройстве и root для плашки ──

    data class RootInfoData(
        val model: String,
        val android: String,
        val kernel: String,
        val suPath: String?,
        val selinux: String,
        val rootId: String?,
    )

    suspend fun collectInfo(): RootInfoData = withContext(Dispatchers.IO) {
        val suCandidates = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/vendor/bin/su",
            "/product/bin/su", "/data/adb/ksu/bin/su", "/system/sbin/su",
        )
        val su = suCandidates.firstOrNull { File(it).exists() }
        val selinux = try {
            ProcessBuilder("sh", "-c", "getenforce").redirectErrorStream(true).start()
                .inputStream.bufferedReader().readText().trim()
        } catch (_: Exception) {
            ""
        }
        val kernel = (System.getProperty("os.version") ?: "?") + " (" + (System.getProperty("os.arch") ?: "?") + ")"
        val id = if (rootReady) execRoot("id")?.second?.trim() else null
        RootInfoData(
            model = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL,
            android = android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")",
            kernel = kernel,
            suPath = su,
            selinux = selinux,
            rootId = id,
        )
    }
}

/** Файловые операции через shell: для папок, куда обычному приложению нельзя. */
object ShellFs {
    private val restrictedRe = Regex("^(/storage/[^/]+|/sdcard|/storage/emulated/\\d+)/Android/(data|obb)(/.*)?$")

    /** Системные пути вне общего хранилища: корневой каталог, /data, /system и т.д. */
    fun isSystemPath(path: String): Boolean =
        !(path == "/storage" || path.startsWith("/storage/") || path == "/sdcard" || path.startsWith("/sdcard/"))

    /** Нужен ли shell: Android/data и Android/obb всегда; системные пути — когда включён root. */
    fun needsShell(path: String): Boolean = restrictedRe.matches(path) || (Shell.rootReady && isSystemPath(path))

    /** Есть ли чем работать с этим путём (для системных путей нужен именно root). */
    fun availableFor(path: String): Boolean = if (isSystemPath(path)) Shell.rootReady else Shell.available

    fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun run(cmd: String, root: Boolean): Pair<Int, String> = Shell.exec(cmd, preferRoot = root) ?: (-1 to "")

    fun exists(path: String) = run("[ -e ${q(path)} ] && echo 1", isSystemPath(path)).second.trim() == "1"

    fun list(path: String): List<FileItem>? {
        val cmd = "cd ${q(path)} 2>/dev/null || exit 3; " +
            "for f in * .[!.]* ..?*; do [ -e \"\$f\" ] || [ -L \"\$f\" ] || continue; " +
            "stat -c '%F|%s|%Y|%n' \"\$f\"; done"
        val (code, out) = Shell.exec(cmd, preferRoot = isSystemPath(path)) ?: return null
        if (code == 3) return emptyList()
        return out.lineSequence().mapNotNull { line ->
            val parts = line.split('|', limit = 4)
            if (parts.size < 4) return@mapNotNull null
            val isDir = parts[0].contains("directory")
            val name = parts[3]
            FileItem(
                path = path.trimEnd('/') + "/" + name,
                name = name,
                isDir = isDir,
                size = if (isDir) 0L else parts[1].toLongOrNull() ?: 0L,
                modified = (parts[2].toLongOrNull() ?: 0L) * 1000,
                kind = kindOf(name, isDir),
            )
        }.toList()
    }

    fun totalSize(path: String): Long =
        (run("du -sk ${q(path)} 2>/dev/null | cut -f1", isSystemPath(path)).second.trim().toLongOrNull() ?: 0L) * 1024

    fun uniqueTarget(dir: String, name: String): String {
        var target = dir.trimEnd('/') + "/" + name
        if (!exists(target)) return target
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (exists(target)) {
            target = dir.trimEnd('/') + "/" + "$base ($i)$ext"
            i++
        }
        return target
    }

    private fun anySystem(a: String, b: String) = isSystemPath(a) || isSystemPath(b)

    fun cp(src: String, dst: String) = run("cp -r ${q(src)} ${q(dst)}", anySystem(src, dst)).first == 0
    fun mv(src: String, dst: String) = run("mv ${q(src)} ${q(dst)}", anySystem(src, dst)).first == 0
    fun rm(path: String) = run("rm -rf ${q(path)}", isSystemPath(path)).first == 0
    fun mkdir(path: String) = run("mkdir -p ${q(path)}", isSystemPath(path)).first == 0
    fun touch(path: String) = run("touch ${q(path)}", isSystemPath(path)).first == 0

    /** Скопировать файл в доступное место, чтобы открыть его обычным способом. */
    fun stage(path: String): File? {
        val dir = File(Environment.getExternalStorageDirectory(), ".Mat3Stage").apply { mkdirs() }
        val target = File(dir, System.currentTimeMillis().toString() + "_" + path.substringAfterLast('/'))
        val cmd = "cp ${q(path)} ${q(target.absolutePath)} && chmod 666 ${q(target.absolutePath)}"
        return if (run(cmd, isSystemPath(path)).first == 0) target else null
    }

    /** Записать правку обратно в исходный файл. */
    fun writeBack(staged: File, path: String) = run("cp ${q(staged.absolutePath)} ${q(path)}", isSystemPath(path)).first == 0
}
